﻿namespace CsdUtilities.OMR
{
    partial class frmObjScanning
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmObjScanning));
            this.scMain = new System.Windows.Forms.SplitContainer();
            this.lblHeader = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tcOmr = new System.Windows.Forms.TabControl();
            this.tpOmrDataCapture = new System.Windows.Forms.TabPage();
            this.scMid = new System.Windows.Forms.SplitContainer();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbAbsentCheck = new System.Windows.Forms.CheckBox();
            this.cbLess15Check = new System.Windows.Forms.CheckBox();
            this.rbNanhaoData = new System.Windows.Forms.RadioButton();
            this.rbDrsData = new System.Windows.Forms.RadioButton();
            this.btnPasteDataFromCB = new System.Windows.Forms.Button();
            this.btnClearRtbs = new System.Windows.Forms.Button();
            this.btnSaveScanned = new System.Windows.Forms.Button();
            this.btnClean = new System.Windows.Forms.Button();
            this.scRight = new System.Windows.Forms.SplitContainer();
            this.scTop = new System.Windows.Forms.SplitContainer();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.rtbData = new System.Windows.Forms.RichTextBox();
            this.rtbOutput = new System.Windows.Forms.RichTextBox();
            this.lblTotalCleanLines = new System.Windows.Forms.Label();
            this.lblTotalLines = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.pgStatus = new System.Windows.Forms.ProgressBar();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.scRtfDisplay = new System.Windows.Forms.SplitContainer();
            this.rtbDisplay = new System.Windows.Forms.RichTextBox();
            this.btnSaveRtbDisplay = new System.Windows.Forms.Button();
            this.btnClearRtbDisplay = new System.Windows.Forms.Button();
            this.rtbRejectDisplay = new System.Windows.Forms.RichTextBox();
            this.tpViewExport = new System.Windows.Forms.TabPage();
            this.gbViewExport = new System.Windows.Forms.GroupBox();
            this.btnSortAscDesc = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.cmbViewSpecificUser = new System.Windows.Forms.ComboBox();
            this.rbViewSpecificUser = new System.Windows.Forms.RadioButton();
            this.rbViewIncompleteCentres = new System.Windows.Forms.RadioButton();
            this.dtpViewSpecificDate = new System.Windows.Forms.DateTimePicker();
            this.rbViewSpecificDate = new System.Windows.Forms.RadioButton();
            this.rbViewAll = new System.Windows.Forms.RadioButton();
            this.btnRefreshCentres = new System.Windows.Forms.Button();
            this.lblSelectedSubject = new System.Windows.Forms.Label();
            this.lvSubjDetails = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader16 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader17 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cbExamYear = new System.Windows.Forms.ComboBox();
            this.cbExams = new System.Windows.Forms.ComboBox();
            this.lbCsdSubjCode = new System.Windows.Forms.ListBox();
            this.cmslbCsdSubjCode = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmiLoad = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tmsiClear = new System.Windows.Forms.ToolStripMenuItem();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExportAll = new System.Windows.Forms.Button();
            this.btnExportSelected = new System.Windows.Forms.Button();
            this.btnLoadScanned = new System.Windows.Forms.Button();
            this.tpQueryResolution = new System.Windows.Forms.TabPage();
            this.scQrsMain = new System.Windows.Forms.SplitContainer();
            this.scQryRes = new System.Windows.Forms.SplitContainer();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnSearchQrsCandidate = new System.Windows.Forms.Button();
            this.gbQrsCheckCandidate = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.btnQrsCheckShowAbsents = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.cbQrsCheckShowUnscored = new System.Windows.Forms.CheckBox();
            this.cbQrsCheckShowManuallyKeyed = new System.Windows.Forms.CheckBox();
            this.btnQrsCheckClear = new System.Windows.Forms.Button();
            this.btnSearchCheckCandidate = new System.Windows.Forms.Button();
            this.lvQrsCheckCandidate = new System.Windows.Forms.ListView();
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.txtQrsCheckIndexNo = new System.Windows.Forms.TextBox();
            this.txtQrsCheckCentNo = new System.Windows.Forms.TextBox();
            this.txtQrsCheckExamYear = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.btnEnterUnscanned = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.scQrsData = new System.Windows.Forms.SplitContainer();
            this.btnQrsShowKeyPad = new System.Windows.Forms.Button();
            this.rbQrsStartFromIndex = new System.Windows.Forms.RadioButton();
            this.rbQrsStartFromCent = new System.Windows.Forms.RadioButton();
            this.label23 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.BtnQrsClear = new System.Windows.Forms.Button();
            this.btnQrsSaveData = new System.Windows.Forms.Button();
            this.cbQrsAbsent = new System.Windows.Forms.CheckBox();
            this.txtQrsSubjCode = new System.Windows.Forms.TextBox();
            this.txtQrsIndexNumber = new System.Windows.Forms.TextBox();
            this.txtQrsCentreNumber = new System.Windows.Forms.TextBox();
            this.cbQrsSex = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.txtQrsExamYear = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.gbQrsKeypad = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.btnQrsMulti = new System.Windows.Forms.Button();
            this.btnQrsSpace = new System.Windows.Forms.Button();
            this.btnQrsD = new System.Windows.Forms.Button();
            this.btnQrsC = new System.Windows.Forms.Button();
            this.btnQrsB = new System.Windows.Forms.Button();
            this.btnQrsA = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.lblCurrentCaretPosition = new System.Windows.Forms.Label();
            this.lblCurrentQuestion = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txtQrsDataConfirm = new System.Windows.Forms.TextBox();
            this.txtQrsData = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.scQrsLeft = new System.Windows.Forms.SplitContainer();
            this.tpScore = new System.Windows.Forms.TabPage();
            this.scScoreMain = new System.Windows.Forms.SplitContainer();
            this.panel1 = new System.Windows.Forms.Panel();
            this.scKeysView = new System.Windows.Forms.SplitContainer();
            this.lbAvailableKeys = new System.Windows.Forms.ListBox();
            this.btnLoadSelectedKey = new System.Windows.Forms.Button();
            this.cbKeysExamType = new System.Windows.Forms.ComboBox();
            this.cbKeysExamYear = new System.Windows.Forms.ComboBox();
            this.btnKeysRefresh = new System.Windows.Forms.Button();
            this.scKeysViewDetails = new System.Windows.Forms.SplitContainer();
            this.rtbKeysView = new System.Windows.Forms.RichTextBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.button9 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.label11 = new System.Windows.Forms.Label();
            this.nupRows = new System.Windows.Forms.NumericUpDown();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.btnScrollKeysRight = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.btnScrollKeysLeft = new System.Windows.Forms.Button();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.btnKeysZoomPlus = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.btnKeysZoomMinus = new System.Windows.Forms.Button();
            this.scScore = new System.Windows.Forms.SplitContainer();
            this.btnShowScore = new System.Windows.Forms.Button();
            this.scScoreMid = new System.Windows.Forms.SplitContainer();
            this.scScoreLeftMid = new System.Windows.Forms.SplitContainer();
            this.scScoreLeft = new System.Windows.Forms.SplitContainer();
            this.gbScoreOptions = new System.Windows.Forms.GroupBox();
            this.cbScoreblankAbsentData = new System.Windows.Forms.CheckBox();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnLoadKeys = new System.Windows.Forms.Button();
            this.cbScoreExamType = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cbScoreExamYear = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.lvScoringKeys = new System.Windows.Forms.ListView();
            this.chCsdSubjCode = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chExamYear = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chNoOfItems = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chKeyData = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pgScoring = new System.Windows.Forms.ProgressBar();
            this.splitContainer6 = new System.Windows.Forms.SplitContainer();
            this.rtbScoreDisplay = new System.Windows.Forms.RichTextBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.btnExitScore = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.btnView = new System.Windows.Forms.Button();
            this.btnScoreMissing = new System.Windows.Forms.Button();
            this.btnScoreSelected = new System.Windows.Forms.Button();
            this.panelMain = new System.Windows.Forms.Panel();
            this.rtbQrsDisplay = new System.Windows.Forms.RichTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.scMain)).BeginInit();
            this.scMain.Panel1.SuspendLayout();
            this.scMain.Panel2.SuspendLayout();
            this.scMain.SuspendLayout();
            this.tcOmr.SuspendLayout();
            this.tpOmrDataCapture.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scMid)).BeginInit();
            this.scMid.Panel1.SuspendLayout();
            this.scMid.Panel2.SuspendLayout();
            this.scMid.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scRight)).BeginInit();
            this.scRight.Panel1.SuspendLayout();
            this.scRight.Panel2.SuspendLayout();
            this.scRight.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scTop)).BeginInit();
            this.scTop.Panel1.SuspendLayout();
            this.scTop.Panel2.SuspendLayout();
            this.scTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scRtfDisplay)).BeginInit();
            this.scRtfDisplay.Panel1.SuspendLayout();
            this.scRtfDisplay.Panel2.SuspendLayout();
            this.scRtfDisplay.SuspendLayout();
            this.tpViewExport.SuspendLayout();
            this.gbViewExport.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.cmslbCsdSubjCode.SuspendLayout();
            this.tpQueryResolution.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scQrsMain)).BeginInit();
            this.scQrsMain.Panel1.SuspendLayout();
            this.scQrsMain.Panel2.SuspendLayout();
            this.scQrsMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scQryRes)).BeginInit();
            this.scQryRes.Panel1.SuspendLayout();
            this.scQryRes.Panel2.SuspendLayout();
            this.scQryRes.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.gbQrsCheckCandidate.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scQrsData)).BeginInit();
            this.scQrsData.Panel1.SuspendLayout();
            this.scQrsData.Panel2.SuspendLayout();
            this.scQrsData.SuspendLayout();
            this.gbQrsKeypad.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scQrsLeft)).BeginInit();
            this.scQrsLeft.SuspendLayout();
            this.tpScore.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scScoreMain)).BeginInit();
            this.scScoreMain.Panel1.SuspendLayout();
            this.scScoreMain.Panel2.SuspendLayout();
            this.scScoreMain.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scKeysView)).BeginInit();
            this.scKeysView.Panel1.SuspendLayout();
            this.scKeysView.Panel2.SuspendLayout();
            this.scKeysView.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scKeysViewDetails)).BeginInit();
            this.scKeysViewDetails.Panel1.SuspendLayout();
            this.scKeysViewDetails.Panel2.SuspendLayout();
            this.scKeysViewDetails.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nupRows)).BeginInit();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scScore)).BeginInit();
            this.scScore.Panel1.SuspendLayout();
            this.scScore.Panel2.SuspendLayout();
            this.scScore.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scScoreMid)).BeginInit();
            this.scScoreMid.Panel1.SuspendLayout();
            this.scScoreMid.Panel2.SuspendLayout();
            this.scScoreMid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scScoreLeftMid)).BeginInit();
            this.scScoreLeftMid.Panel1.SuspendLayout();
            this.scScoreLeftMid.Panel2.SuspendLayout();
            this.scScoreLeftMid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scScoreLeft)).BeginInit();
            this.scScoreLeft.Panel1.SuspendLayout();
            this.scScoreLeft.Panel2.SuspendLayout();
            this.scScoreLeft.SuspendLayout();
            this.gbScoreOptions.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).BeginInit();
            this.splitContainer6.Panel1.SuspendLayout();
            this.splitContainer6.Panel2.SuspendLayout();
            this.splitContainer6.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panelMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // scMain
            // 
            this.scMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.scMain.Location = new System.Drawing.Point(4, 4);
            this.scMain.Margin = new System.Windows.Forms.Padding(4);
            this.scMain.Name = "scMain";
            this.scMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // scMain.Panel1
            // 
            this.scMain.Panel1.Controls.Add(this.lblHeader);
            this.scMain.Panel1.Controls.Add(this.label1);
            // 
            // scMain.Panel2
            // 
            this.scMain.Panel2.AutoScroll = true;
            this.scMain.Panel2.Controls.Add(this.tcOmr);
            this.scMain.Panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.scMain_Panel2_Paint);
            this.scMain.Size = new System.Drawing.Size(1582, 860);
            this.scMain.SplitterDistance = 116;
            this.scMain.SplitterWidth = 5;
            this.scMain.TabIndex = 0;
            // 
            // lblHeader
            // 
            this.lblHeader.AutoSize = true;
            this.lblHeader.Dock = System.Windows.Forms.DockStyle.Right;
            this.lblHeader.Font = new System.Drawing.Font("Times New Roman", 28F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeader.Location = new System.Drawing.Point(1164, 0);
            this.lblHeader.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHeader.Name = "lblHeader";
            this.lblHeader.Size = new System.Drawing.Size(414, 104);
            this.lblHeader.TabIndex = 0;
            this.lblHeader.Text = "OMR Scanning and\r\nProcessing";
            this.lblHeader.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblHeader.Click += new System.EventHandler(this.lblHeader_Click);
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Left;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 28F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Image = ((System.Drawing.Image)(resources.GetObject("label1.Image")));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1192, 112);
            this.label1.TabIndex = 1;
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tcOmr
            // 
            this.tcOmr.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tcOmr.Controls.Add(this.tpOmrDataCapture);
            this.tcOmr.Controls.Add(this.tpViewExport);
            this.tcOmr.Controls.Add(this.tpQueryResolution);
            this.tcOmr.Controls.Add(this.tpScore);
            this.tcOmr.Location = new System.Drawing.Point(0, 189);
            this.tcOmr.Margin = new System.Windows.Forms.Padding(4);
            this.tcOmr.Name = "tcOmr";
            this.tcOmr.SelectedIndex = 0;
            this.tcOmr.Size = new System.Drawing.Size(1553, 739);
            this.tcOmr.TabIndex = 0;
            this.tcOmr.SelectedIndexChanged += new System.EventHandler(this.tcOmr_SelectedIndexChanged);
            // 
            // tpOmrDataCapture
            // 
            this.tpOmrDataCapture.BackColor = System.Drawing.Color.Olive;
            this.tpOmrDataCapture.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tpOmrDataCapture.Controls.Add(this.scMid);
            this.tpOmrDataCapture.Location = new System.Drawing.Point(4, 28);
            this.tpOmrDataCapture.Margin = new System.Windows.Forms.Padding(4);
            this.tpOmrDataCapture.Name = "tpOmrDataCapture";
            this.tpOmrDataCapture.Padding = new System.Windows.Forms.Padding(4);
            this.tpOmrDataCapture.Size = new System.Drawing.Size(1545, 706);
            this.tpOmrDataCapture.TabIndex = 0;
            this.tpOmrDataCapture.Text = "OMR Data Capture";
            // 
            // scMid
            // 
            this.scMid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scMid.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.scMid.IsSplitterFixed = true;
            this.scMid.Location = new System.Drawing.Point(4, 4);
            this.scMid.Margin = new System.Windows.Forms.Padding(4);
            this.scMid.Name = "scMid";
            // 
            // scMid.Panel1
            // 
            this.scMid.Panel1.Controls.Add(this.label4);
            this.scMid.Panel1.Controls.Add(this.groupBox1);
            this.scMid.Panel1.Controls.Add(this.btnSaveScanned);
            this.scMid.Panel1.Controls.Add(this.btnClean);
            this.scMid.Panel1.ForeColor = System.Drawing.Color.Black;
            this.scMid.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.scMid_Panel1_Paint);
            // 
            // scMid.Panel2
            // 
            this.scMid.Panel2.Controls.Add(this.scRight);
            this.scMid.Size = new System.Drawing.Size(1535, 696);
            this.scMid.SplitterDistance = 144;
            this.scMid.SplitterWidth = 5;
            this.scMid.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.World, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(211, 92);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(1117, 100);
            this.label4.TabIndex = 4;
            this.label4.Text = "Start by clicking on \"Paste Data\". This will start the saving process.";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbAbsentCheck);
            this.groupBox1.Controls.Add(this.cbLess15Check);
            this.groupBox1.Controls.Add(this.rbNanhaoData);
            this.groupBox1.Controls.Add(this.rbDrsData);
            this.groupBox1.Controls.Add(this.btnPasteDataFromCB);
            this.groupBox1.Controls.Add(this.btnClearRtbs);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(5, 0);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(175, 300);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            // 
            // cbAbsentCheck
            // 
            this.cbAbsentCheck.AutoSize = true;
            this.cbAbsentCheck.Checked = true;
            this.cbAbsentCheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbAbsentCheck.Enabled = false;
            this.cbAbsentCheck.Location = new System.Drawing.Point(9, 210);
            this.cbAbsentCheck.Margin = new System.Windows.Forms.Padding(4);
            this.cbAbsentCheck.Name = "cbAbsentCheck";
            this.cbAbsentCheck.Size = new System.Drawing.Size(117, 21);
            this.cbAbsentCheck.TabIndex = 2;
            this.cbAbsentCheck.Text = "Absent Check";
            this.cbAbsentCheck.UseVisualStyleBackColor = true;
            this.cbAbsentCheck.Visible = false;
            // 
            // cbLess15Check
            // 
            this.cbLess15Check.AutoSize = true;
            this.cbLess15Check.Location = new System.Drawing.Point(9, 185);
            this.cbLess15Check.Margin = new System.Windows.Forms.Padding(4);
            this.cbLess15Check.Name = "cbLess15Check";
            this.cbLess15Check.Size = new System.Drawing.Size(101, 21);
            this.cbLess15Check.TabIndex = 2;
            this.cbLess15Check.Text = "< 15 Check";
            this.cbLess15Check.UseVisualStyleBackColor = true;
            // 
            // rbNanhaoData
            // 
            this.rbNanhaoData.AutoSize = true;
            this.rbNanhaoData.Checked = true;
            this.rbNanhaoData.Location = new System.Drawing.Point(21, 49);
            this.rbNanhaoData.Margin = new System.Windows.Forms.Padding(4);
            this.rbNanhaoData.Name = "rbNanhaoData";
            this.rbNanhaoData.Size = new System.Drawing.Size(115, 21);
            this.rbNanhaoData.TabIndex = 1;
            this.rbNanhaoData.TabStop = true;
            this.rbNanhaoData.Text = "NanHao Data";
            this.rbNanhaoData.UseVisualStyleBackColor = true;
            this.rbNanhaoData.CheckedChanged += new System.EventHandler(this.rbScanners_CheckedChanged);
            // 
            // rbDrsData
            // 
            this.rbDrsData.AutoSize = true;
            this.rbDrsData.Location = new System.Drawing.Point(21, 21);
            this.rbDrsData.Margin = new System.Windows.Forms.Padding(4);
            this.rbDrsData.Name = "rbDrsData";
            this.rbDrsData.Size = new System.Drawing.Size(92, 21);
            this.rbDrsData.TabIndex = 1;
            this.rbDrsData.Text = "DRS Data";
            this.rbDrsData.UseVisualStyleBackColor = true;
            this.rbDrsData.CheckedChanged += new System.EventHandler(this.rbScanners_CheckedChanged);
            // 
            // btnPasteDataFromCB
            // 
            this.btnPasteDataFromCB.ForeColor = System.Drawing.Color.Black;
            this.btnPasteDataFromCB.Location = new System.Drawing.Point(8, 92);
            this.btnPasteDataFromCB.Margin = new System.Windows.Forms.Padding(4);
            this.btnPasteDataFromCB.Name = "btnPasteDataFromCB";
            this.btnPasteDataFromCB.Size = new System.Drawing.Size(152, 85);
            this.btnPasteDataFromCB.TabIndex = 0;
            this.btnPasteDataFromCB.Text = "Paste Data";
            this.btnPasteDataFromCB.UseVisualStyleBackColor = true;
            this.btnPasteDataFromCB.Click += new System.EventHandler(this.btnPasteDataFromCB_Click);
            // 
            // btnClearRtbs
            // 
            this.btnClearRtbs.ForeColor = System.Drawing.Color.Black;
            this.btnClearRtbs.Location = new System.Drawing.Point(8, 235);
            this.btnClearRtbs.Margin = new System.Windows.Forms.Padding(4);
            this.btnClearRtbs.Name = "btnClearRtbs";
            this.btnClearRtbs.Size = new System.Drawing.Size(152, 58);
            this.btnClearRtbs.TabIndex = 0;
            this.btnClearRtbs.Text = "Clear";
            this.btnClearRtbs.UseVisualStyleBackColor = true;
            this.btnClearRtbs.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnSaveScanned
            // 
            this.btnSaveScanned.Location = new System.Drawing.Point(5, 444);
            this.btnSaveScanned.Margin = new System.Windows.Forms.Padding(4);
            this.btnSaveScanned.Name = "btnSaveScanned";
            this.btnSaveScanned.Size = new System.Drawing.Size(176, 121);
            this.btnSaveScanned.TabIndex = 0;
            this.btnSaveScanned.Text = "Save";
            this.btnSaveScanned.UseVisualStyleBackColor = true;
            this.btnSaveScanned.Visible = false;
            this.btnSaveScanned.Click += new System.EventHandler(this.btnSaveScanned_Click);
            // 
            // btnClean
            // 
            this.btnClean.Location = new System.Drawing.Point(5, 316);
            this.btnClean.Margin = new System.Windows.Forms.Padding(4);
            this.btnClean.Name = "btnClean";
            this.btnClean.Size = new System.Drawing.Size(176, 121);
            this.btnClean.TabIndex = 0;
            this.btnClean.Text = "Clean Data";
            this.btnClean.UseVisualStyleBackColor = true;
            this.btnClean.Visible = false;
            this.btnClean.Click += new System.EventHandler(this.btnClean_Click);
            // 
            // scRight
            // 
            this.scRight.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scRight.Location = new System.Drawing.Point(0, 0);
            this.scRight.Margin = new System.Windows.Forms.Padding(4);
            this.scRight.Name = "scRight";
            this.scRight.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // scRight.Panel1
            // 
            this.scRight.Panel1.Controls.Add(this.scTop);
            // 
            // scRight.Panel2
            // 
            this.scRight.Panel2.Controls.Add(this.splitContainer1);
            this.scRight.Size = new System.Drawing.Size(1386, 696);
            this.scRight.SplitterDistance = 106;
            this.scRight.SplitterWidth = 5;
            this.scRight.TabIndex = 0;
            // 
            // scTop
            // 
            this.scTop.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scTop.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.scTop.ForeColor = System.Drawing.Color.Black;
            this.scTop.Location = new System.Drawing.Point(0, 0);
            this.scTop.Margin = new System.Windows.Forms.Padding(4);
            this.scTop.Name = "scTop";
            // 
            // scTop.Panel1
            // 
            this.scTop.Panel1.Controls.Add(this.splitContainer3);
            // 
            // scTop.Panel2
            // 
            this.scTop.Panel2.Controls.Add(this.lblTotalCleanLines);
            this.scTop.Panel2.Controls.Add(this.lblTotalLines);
            this.scTop.Panel2.Controls.Add(this.label3);
            this.scTop.Panel2.Controls.Add(this.label2);
            this.scTop.Panel2.ForeColor = System.Drawing.Color.White;
            this.scTop.Size = new System.Drawing.Size(1386, 106);
            this.scTop.SplitterDistance = 899;
            this.scTop.SplitterWidth = 5;
            this.scTop.TabIndex = 0;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer3.Name = "splitContainer3";
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.rtbData);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.rtbOutput);
            this.splitContainer3.Size = new System.Drawing.Size(899, 106);
            this.splitContainer3.SplitterDistance = 332;
            this.splitContainer3.SplitterWidth = 5;
            this.splitContainer3.TabIndex = 2;
            // 
            // rtbData
            // 
            this.rtbData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbData.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbData.Location = new System.Drawing.Point(0, 0);
            this.rtbData.Margin = new System.Windows.Forms.Padding(4);
            this.rtbData.Name = "rtbData";
            this.rtbData.ReadOnly = true;
            this.rtbData.Size = new System.Drawing.Size(332, 106);
            this.rtbData.TabIndex = 1;
            this.rtbData.Text = "";
            this.rtbData.WordWrap = false;
            this.rtbData.TextChanged += new System.EventHandler(this.rtbData_TextChanged);
            // 
            // rtbOutput
            // 
            this.rtbOutput.BackColor = System.Drawing.Color.Thistle;
            this.rtbOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbOutput.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbOutput.Location = new System.Drawing.Point(0, 0);
            this.rtbOutput.Margin = new System.Windows.Forms.Padding(4);
            this.rtbOutput.Name = "rtbOutput";
            this.rtbOutput.ReadOnly = true;
            this.rtbOutput.Size = new System.Drawing.Size(562, 106);
            this.rtbOutput.TabIndex = 1;
            this.rtbOutput.Text = "";
            this.rtbOutput.WordWrap = false;
            // 
            // lblTotalCleanLines
            // 
            this.lblTotalCleanLines.AutoSize = true;
            this.lblTotalCleanLines.Location = new System.Drawing.Point(65, 95);
            this.lblTotalCleanLines.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalCleanLines.Name = "lblTotalCleanLines";
            this.lblTotalCleanLines.Size = new System.Drawing.Size(16, 17);
            this.lblTotalCleanLines.TabIndex = 1;
            this.lblTotalCleanLines.Text = "0";
            this.lblTotalCleanLines.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblTotalCleanLines.Click += new System.EventHandler(this.label4_Click);
            // 
            // lblTotalLines
            // 
            this.lblTotalLines.AutoSize = true;
            this.lblTotalLines.Location = new System.Drawing.Point(65, 39);
            this.lblTotalLines.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalLines.Name = "lblTotalLines";
            this.lblTotalLines.Size = new System.Drawing.Size(16, 17);
            this.lblTotalLines.TabIndex = 1;
            this.lblTotalLines.Text = "0";
            this.lblTotalLines.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblTotalLines.Click += new System.EventHandler(this.lblTotalLines_Click);
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(24, 66);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 28);
            this.label3.TabIndex = 0;
            this.label3.Text = "Total Clean Lines";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(21, 11);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 28);
            this.label2.TabIndex = 0;
            this.label2.Text = "Total Lines";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitContainer1.ForeColor = System.Drawing.Color.Black;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.ForeColor = System.Drawing.Color.White;
            this.splitContainer1.Size = new System.Drawing.Size(1386, 585);
            this.splitContainer1.SplitterDistance = 898;
            this.splitContainer1.SplitterWidth = 5;
            this.splitContainer1.TabIndex = 1;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.pgStatus);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.groupBox2);
            this.splitContainer2.Panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer2_Panel2_Paint);
            this.splitContainer2.Size = new System.Drawing.Size(898, 585);
            this.splitContainer2.SplitterDistance = 25;
            this.splitContainer2.SplitterWidth = 5;
            this.splitContainer2.TabIndex = 0;
            // 
            // pgStatus
            // 
            this.pgStatus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pgStatus.Location = new System.Drawing.Point(0, 0);
            this.pgStatus.Margin = new System.Windows.Forms.Padding(4);
            this.pgStatus.Name = "pgStatus";
            this.pgStatus.Size = new System.Drawing.Size(898, 25);
            this.pgStatus.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.scRtfDisplay);
            this.groupBox2.Location = new System.Drawing.Point(4, 0);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(1053, 442);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // scRtfDisplay
            // 
            this.scRtfDisplay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scRtfDisplay.Location = new System.Drawing.Point(4, 19);
            this.scRtfDisplay.Margin = new System.Windows.Forms.Padding(4);
            this.scRtfDisplay.Name = "scRtfDisplay";
            this.scRtfDisplay.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // scRtfDisplay.Panel1
            // 
            this.scRtfDisplay.Panel1.Controls.Add(this.rtbDisplay);
            this.scRtfDisplay.Panel1.Controls.Add(this.btnSaveRtbDisplay);
            this.scRtfDisplay.Panel1.Controls.Add(this.btnClearRtbDisplay);
            // 
            // scRtfDisplay.Panel2
            // 
            this.scRtfDisplay.Panel2.Controls.Add(this.rtbRejectDisplay);
            this.scRtfDisplay.Panel2Collapsed = true;
            this.scRtfDisplay.Size = new System.Drawing.Size(1045, 419);
            this.scRtfDisplay.SplitterDistance = 170;
            this.scRtfDisplay.SplitterWidth = 5;
            this.scRtfDisplay.TabIndex = 1;
            // 
            // rtbDisplay
            // 
            this.rtbDisplay.BackColor = System.Drawing.Color.Gainsboro;
            this.rtbDisplay.Dock = System.Windows.Forms.DockStyle.Left;
            this.rtbDisplay.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbDisplay.Location = new System.Drawing.Point(0, 0);
            this.rtbDisplay.Margin = new System.Windows.Forms.Padding(4);
            this.rtbDisplay.Name = "rtbDisplay";
            this.rtbDisplay.ReadOnly = true;
            this.rtbDisplay.Size = new System.Drawing.Size(889, 419);
            this.rtbDisplay.TabIndex = 0;
            this.rtbDisplay.Text = "";
            this.rtbDisplay.WordWrap = false;
            this.rtbDisplay.TextChanged += new System.EventHandler(this.rtbDisplay_TextChanged);
            this.rtbDisplay.DoubleClick += new System.EventHandler(this.rtbDisplay_DoubleClick);
            // 
            // btnSaveRtbDisplay
            // 
            this.btnSaveRtbDisplay.Enabled = false;
            this.btnSaveRtbDisplay.Location = new System.Drawing.Point(899, 66);
            this.btnSaveRtbDisplay.Margin = new System.Windows.Forms.Padding(4);
            this.btnSaveRtbDisplay.Name = "btnSaveRtbDisplay";
            this.btnSaveRtbDisplay.Size = new System.Drawing.Size(143, 49);
            this.btnSaveRtbDisplay.TabIndex = 0;
            this.btnSaveRtbDisplay.Text = "Save ...";
            this.btnSaveRtbDisplay.UseVisualStyleBackColor = true;
            // 
            // btnClearRtbDisplay
            // 
            this.btnClearRtbDisplay.Location = new System.Drawing.Point(899, 10);
            this.btnClearRtbDisplay.Margin = new System.Windows.Forms.Padding(4);
            this.btnClearRtbDisplay.Name = "btnClearRtbDisplay";
            this.btnClearRtbDisplay.Size = new System.Drawing.Size(143, 49);
            this.btnClearRtbDisplay.TabIndex = 0;
            this.btnClearRtbDisplay.Text = "Clear";
            this.btnClearRtbDisplay.UseVisualStyleBackColor = true;
            this.btnClearRtbDisplay.Click += new System.EventHandler(this.btnClearRtbDisplay_Click);
            // 
            // rtbRejectDisplay
            // 
            this.rtbRejectDisplay.BackColor = System.Drawing.Color.Chocolate;
            this.rtbRejectDisplay.DetectUrls = false;
            this.rtbRejectDisplay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbRejectDisplay.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbRejectDisplay.Location = new System.Drawing.Point(0, 0);
            this.rtbRejectDisplay.Margin = new System.Windows.Forms.Padding(4);
            this.rtbRejectDisplay.Name = "rtbRejectDisplay";
            this.rtbRejectDisplay.ReadOnly = true;
            this.rtbRejectDisplay.Size = new System.Drawing.Size(150, 46);
            this.rtbRejectDisplay.TabIndex = 1;
            this.rtbRejectDisplay.Text = "";
            this.rtbRejectDisplay.WordWrap = false;
            this.rtbRejectDisplay.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.rtbRejectDisplay_MouseDoubleClick);
            // 
            // tpViewExport
            // 
            this.tpViewExport.BackColor = System.Drawing.Color.Olive;
            this.tpViewExport.Controls.Add(this.gbViewExport);
            this.tpViewExport.Location = new System.Drawing.Point(4, 28);
            this.tpViewExport.Margin = new System.Windows.Forms.Padding(4);
            this.tpViewExport.Name = "tpViewExport";
            this.tpViewExport.Padding = new System.Windows.Forms.Padding(4);
            this.tpViewExport.Size = new System.Drawing.Size(1545, 706);
            this.tpViewExport.TabIndex = 1;
            this.tpViewExport.Text = "View and Export";
            // 
            // gbViewExport
            // 
            this.gbViewExport.Controls.Add(this.btnSortAscDesc);
            this.gbViewExport.Controls.Add(this.groupBox8);
            this.gbViewExport.Controls.Add(this.lblSelectedSubject);
            this.gbViewExport.Controls.Add(this.lvSubjDetails);
            this.gbViewExport.Controls.Add(this.label6);
            this.gbViewExport.Controls.Add(this.label5);
            this.gbViewExport.Controls.Add(this.cbExamYear);
            this.gbViewExport.Controls.Add(this.cbExams);
            this.gbViewExport.Controls.Add(this.lbCsdSubjCode);
            this.gbViewExport.Controls.Add(this.btnClear);
            this.gbViewExport.Controls.Add(this.btnExportAll);
            this.gbViewExport.Controls.Add(this.btnExportSelected);
            this.gbViewExport.Controls.Add(this.btnLoadScanned);
            this.gbViewExport.Location = new System.Drawing.Point(8, -2);
            this.gbViewExport.Margin = new System.Windows.Forms.Padding(4);
            this.gbViewExport.Name = "gbViewExport";
            this.gbViewExport.Padding = new System.Windows.Forms.Padding(4);
            this.gbViewExport.Size = new System.Drawing.Size(1527, 645);
            this.gbViewExport.TabIndex = 0;
            this.gbViewExport.TabStop = false;
            // 
            // btnSortAscDesc
            // 
            this.btnSortAscDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSortAscDesc.ForeColor = System.Drawing.Color.Black;
            this.btnSortAscDesc.Location = new System.Drawing.Point(1463, 26);
            this.btnSortAscDesc.Margin = new System.Windows.Forms.Padding(4);
            this.btnSortAscDesc.Name = "btnSortAscDesc";
            this.btnSortAscDesc.Size = new System.Drawing.Size(56, 39);
            this.btnSortAscDesc.TabIndex = 9;
            this.btnSortAscDesc.Text = "▼";
            this.btnSortAscDesc.UseVisualStyleBackColor = true;
            this.btnSortAscDesc.Click += new System.EventHandler(this.btnSortAscDesc_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.cmbViewSpecificUser);
            this.groupBox8.Controls.Add(this.rbViewSpecificUser);
            this.groupBox8.Controls.Add(this.rbViewIncompleteCentres);
            this.groupBox8.Controls.Add(this.dtpViewSpecificDate);
            this.groupBox8.Controls.Add(this.rbViewSpecificDate);
            this.groupBox8.Controls.Add(this.rbViewAll);
            this.groupBox8.Controls.Add(this.btnRefreshCentres);
            this.groupBox8.ForeColor = System.Drawing.Color.White;
            this.groupBox8.Location = new System.Drawing.Point(581, 527);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox8.Size = new System.Drawing.Size(937, 87);
            this.groupBox8.TabIndex = 8;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Show";
            // 
            // cmbViewSpecificUser
            // 
            this.cmbViewSpecificUser.FormattingEnabled = true;
            this.cmbViewSpecificUser.Location = new System.Drawing.Point(356, 54);
            this.cmbViewSpecificUser.Margin = new System.Windows.Forms.Padding(4);
            this.cmbViewSpecificUser.Name = "cmbViewSpecificUser";
            this.cmbViewSpecificUser.Size = new System.Drawing.Size(265, 24);
            this.cmbViewSpecificUser.Sorted = true;
            this.cmbViewSpecificUser.TabIndex = 13;
            this.cmbViewSpecificUser.Visible = false;
            this.cmbViewSpecificUser.SelectedIndexChanged += new System.EventHandler(this.cmbViewSpecificUser_SelectedIndexChanged);
            // 
            // rbViewSpecificUser
            // 
            this.rbViewSpecificUser.AutoSize = true;
            this.rbViewSpecificUser.Location = new System.Drawing.Point(225, 55);
            this.rbViewSpecificUser.Margin = new System.Windows.Forms.Padding(4);
            this.rbViewSpecificUser.Name = "rbViewSpecificUser";
            this.rbViewSpecificUser.Size = new System.Drawing.Size(63, 21);
            this.rbViewSpecificUser.TabIndex = 12;
            this.rbViewSpecificUser.TabStop = true;
            this.rbViewSpecificUser.Text = "User:";
            this.rbViewSpecificUser.UseVisualStyleBackColor = true;
            this.rbViewSpecificUser.CheckedChanged += new System.EventHandler(this.rbViewSpecificUser_CheckedChanged);
            // 
            // rbViewIncompleteCentres
            // 
            this.rbViewIncompleteCentres.AutoSize = true;
            this.rbViewIncompleteCentres.Location = new System.Drawing.Point(21, 55);
            this.rbViewIncompleteCentres.Margin = new System.Windows.Forms.Padding(4);
            this.rbViewIncompleteCentres.Name = "rbViewIncompleteCentres";
            this.rbViewIncompleteCentres.Size = new System.Drawing.Size(151, 21);
            this.rbViewIncompleteCentres.TabIndex = 11;
            this.rbViewIncompleteCentres.TabStop = true;
            this.rbViewIncompleteCentres.Text = "Incomplete Schools";
            this.rbViewIncompleteCentres.UseVisualStyleBackColor = true;
            this.rbViewIncompleteCentres.CheckedChanged += new System.EventHandler(this.rbViewIncompleteCentres_CheckedChanged);
            // 
            // dtpViewSpecificDate
            // 
            this.dtpViewSpecificDate.Location = new System.Drawing.Point(356, 21);
            this.dtpViewSpecificDate.Margin = new System.Windows.Forms.Padding(4);
            this.dtpViewSpecificDate.Name = "dtpViewSpecificDate";
            this.dtpViewSpecificDate.Size = new System.Drawing.Size(265, 22);
            this.dtpViewSpecificDate.TabIndex = 10;
            this.dtpViewSpecificDate.Visible = false;
            this.dtpViewSpecificDate.ValueChanged += new System.EventHandler(this.dtpViewSpecificDate_ValueChanged);
            // 
            // rbViewSpecificDate
            // 
            this.rbViewSpecificDate.AutoSize = true;
            this.rbViewSpecificDate.Location = new System.Drawing.Point(225, 21);
            this.rbViewSpecificDate.Margin = new System.Windows.Forms.Padding(4);
            this.rbViewSpecificDate.Name = "rbViewSpecificDate";
            this.rbViewSpecificDate.Size = new System.Drawing.Size(116, 21);
            this.rbViewSpecificDate.TabIndex = 9;
            this.rbViewSpecificDate.Text = "Specific Date:";
            this.rbViewSpecificDate.UseVisualStyleBackColor = true;
            this.rbViewSpecificDate.CheckedChanged += new System.EventHandler(this.rbViewSpecificDate_CheckedChanged);
            // 
            // rbViewAll
            // 
            this.rbViewAll.AutoSize = true;
            this.rbViewAll.Checked = true;
            this.rbViewAll.Location = new System.Drawing.Point(21, 21);
            this.rbViewAll.Margin = new System.Windows.Forms.Padding(4);
            this.rbViewAll.Name = "rbViewAll";
            this.rbViewAll.Size = new System.Drawing.Size(44, 21);
            this.rbViewAll.TabIndex = 8;
            this.rbViewAll.TabStop = true;
            this.rbViewAll.Text = "All";
            this.rbViewAll.UseVisualStyleBackColor = true;
            this.rbViewAll.CheckedChanged += new System.EventHandler(this.rbViewAll_CheckedChanged);
            // 
            // btnRefreshCentres
            // 
            this.btnRefreshCentres.ForeColor = System.Drawing.Color.Black;
            this.btnRefreshCentres.Location = new System.Drawing.Point(796, 12);
            this.btnRefreshCentres.Margin = new System.Windows.Forms.Padding(4);
            this.btnRefreshCentres.Name = "btnRefreshCentres";
            this.btnRefreshCentres.Size = new System.Drawing.Size(133, 68);
            this.btnRefreshCentres.TabIndex = 7;
            this.btnRefreshCentres.Text = "Refresh";
            this.btnRefreshCentres.UseVisualStyleBackColor = true;
            this.btnRefreshCentres.Click += new System.EventHandler(this.btnRefreshCentres_Click);
            // 
            // lblSelectedSubject
            // 
            this.lblSelectedSubject.AutoEllipsis = true;
            this.lblSelectedSubject.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectedSubject.Location = new System.Drawing.Point(593, 26);
            this.lblSelectedSubject.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSelectedSubject.Name = "lblSelectedSubject";
            this.lblSelectedSubject.Size = new System.Drawing.Size(767, 41);
            this.lblSelectedSubject.TabIndex = 6;
            this.lblSelectedSubject.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblSelectedSubject.Click += new System.EventHandler(this.lblSelectedSubject_Click);
            // 
            // lvSubjDetails
            // 
            this.lvSubjDetails.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader16,
            this.columnHeader17});
            this.lvSubjDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lvSubjDetails.FullRowSelect = true;
            this.lvSubjDetails.GridLines = true;
            this.lvSubjDetails.Location = new System.Drawing.Point(581, 73);
            this.lvSubjDetails.Margin = new System.Windows.Forms.Padding(4);
            this.lvSubjDetails.MultiSelect = false;
            this.lvSubjDetails.Name = "lvSubjDetails";
            this.lvSubjDetails.Size = new System.Drawing.Size(936, 445);
            this.lvSubjDetails.TabIndex = 5;
            this.lvSubjDetails.UseCompatibleStateImageBehavior = false;
            this.lvSubjDetails.View = System.Windows.Forms.View.Details;
            this.lvSubjDetails.SelectedIndexChanged += new System.EventHandler(this.lvSubjDetails_SelectedIndexChanged);
            this.lvSubjDetails.DoubleClick += new System.EventHandler(this.lvSubjDetails_DoubleClick);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Centre No.";
            this.columnHeader1.Width = 85;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Centre Name";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader2.Width = 160;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Expected";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader3.Width = 90;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Phy. challanged";
            this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader4.Width = 122;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Scanned";
            this.columnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader5.Width = 84;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Difference";
            this.columnHeader6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader6.Width = 83;
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "Date Scanned";
            this.columnHeader16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader16.Width = 66;
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "Scanned By";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(20, 81);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(118, 25);
            this.label6.TabIndex = 4;
            this.label6.Text = "Exam Type:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(20, 27);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(114, 25);
            this.label5.TabIndex = 4;
            this.label5.Text = "Exam Year:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cbExamYear
            // 
            this.cbExamYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbExamYear.FormattingEnabled = true;
            this.cbExamYear.ItemHeight = 31;
            this.cbExamYear.Location = new System.Drawing.Point(148, 18);
            this.cbExamYear.Margin = new System.Windows.Forms.Padding(4);
            this.cbExamYear.Name = "cbExamYear";
            this.cbExamYear.Size = new System.Drawing.Size(255, 39);
            this.cbExamYear.TabIndex = 3;
            this.cbExamYear.SelectedIndexChanged += new System.EventHandler(this.cbExamYear_SelectedIndexChanged);
            // 
            // cbExams
            // 
            this.cbExams.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbExams.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbExams.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbExams.FormattingEnabled = true;
            this.cbExams.ItemHeight = 31;
            this.cbExams.Items.AddRange(new object[] {
            "3 - NAT G3",
            "5 - NAT G5",
            "6 - NAT G8",
            "7 - GABECE",
            "8 - WASSCE",
            "9 - WASSCE"});
            this.cbExams.Location = new System.Drawing.Point(148, 73);
            this.cbExams.Margin = new System.Windows.Forms.Padding(4);
            this.cbExams.Name = "cbExams";
            this.cbExams.Size = new System.Drawing.Size(255, 39);
            this.cbExams.Sorted = true;
            this.cbExams.TabIndex = 3;
            this.cbExams.SelectedIndexChanged += new System.EventHandler(this.cbExams_SelectedIndexChanged);
            this.cbExams.MouseHover += new System.EventHandler(this.cbExams_MouseHover);
            // 
            // lbCsdSubjCode
            // 
            this.lbCsdSubjCode.ContextMenuStrip = this.cmslbCsdSubjCode;
            this.lbCsdSubjCode.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCsdSubjCode.FormattingEnabled = true;
            this.lbCsdSubjCode.HorizontalScrollbar = true;
            this.lbCsdSubjCode.ItemHeight = 22;
            this.lbCsdSubjCode.Location = new System.Drawing.Point(25, 190);
            this.lbCsdSubjCode.Margin = new System.Windows.Forms.Padding(4);
            this.lbCsdSubjCode.Name = "lbCsdSubjCode";
            this.lbCsdSubjCode.Size = new System.Drawing.Size(545, 422);
            this.lbCsdSubjCode.Sorted = true;
            this.lbCsdSubjCode.TabIndex = 2;
            this.lbCsdSubjCode.SelectedIndexChanged += new System.EventHandler(this.lbCsdSubjCode_SelectedIndexChanged);
            this.lbCsdSubjCode.DoubleClick += new System.EventHandler(this.lbCsdSubjCode_DoubleClick);
            // 
            // cmslbCsdSubjCode
            // 
            this.cmslbCsdSubjCode.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.cmslbCsdSubjCode.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiLoad,
            this.toolStripSeparator1,
            this.tmsiClear});
            this.cmslbCsdSubjCode.Name = "cmslbCsdSubjCode";
            this.cmslbCsdSubjCode.Size = new System.Drawing.Size(119, 62);
            // 
            // tsmiLoad
            // 
            this.tsmiLoad.Name = "tsmiLoad";
            this.tsmiLoad.Size = new System.Drawing.Size(118, 26);
            this.tsmiLoad.Text = "Load";
            this.tsmiLoad.Click += new System.EventHandler(this.tsmiLoad_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(115, 6);
            // 
            // tmsiClear
            // 
            this.tmsiClear.Name = "tmsiClear";
            this.tmsiClear.Size = new System.Drawing.Size(118, 26);
            this.tmsiClear.Text = "Clear";
            this.tmsiClear.Click += new System.EventHandler(this.tmsiClear_Click);
            // 
            // btnClear
            // 
            this.btnClear.ForeColor = System.Drawing.Color.Black;
            this.btnClear.Location = new System.Drawing.Point(424, 129);
            this.btnClear.Margin = new System.Windows.Forms.Padding(4);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(148, 48);
            this.btnClear.TabIndex = 0;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExportAll
            // 
            this.btnExportAll.ForeColor = System.Drawing.Color.Black;
            this.btnExportAll.Location = new System.Drawing.Point(424, 74);
            this.btnExportAll.Margin = new System.Windows.Forms.Padding(4);
            this.btnExportAll.Name = "btnExportAll";
            this.btnExportAll.Size = new System.Drawing.Size(148, 48);
            this.btnExportAll.TabIndex = 0;
            this.btnExportAll.Text = "Export All";
            this.btnExportAll.UseVisualStyleBackColor = true;
            this.btnExportAll.Click += new System.EventHandler(this.btnExportAll_Click);
            // 
            // btnExportSelected
            // 
            this.btnExportSelected.ForeColor = System.Drawing.Color.Black;
            this.btnExportSelected.Location = new System.Drawing.Point(424, 18);
            this.btnExportSelected.Margin = new System.Windows.Forms.Padding(4);
            this.btnExportSelected.Name = "btnExportSelected";
            this.btnExportSelected.Size = new System.Drawing.Size(148, 48);
            this.btnExportSelected.TabIndex = 0;
            this.btnExportSelected.Text = "Export Selected";
            this.btnExportSelected.UseVisualStyleBackColor = true;
            this.btnExportSelected.Click += new System.EventHandler(this.btnExportSelected_Click);
            // 
            // btnLoadScanned
            // 
            this.btnLoadScanned.ForeColor = System.Drawing.Color.Black;
            this.btnLoadScanned.Location = new System.Drawing.Point(25, 129);
            this.btnLoadScanned.Margin = new System.Windows.Forms.Padding(4);
            this.btnLoadScanned.Name = "btnLoadScanned";
            this.btnLoadScanned.Size = new System.Drawing.Size(379, 48);
            this.btnLoadScanned.TabIndex = 0;
            this.btnLoadScanned.Text = "Load";
            this.btnLoadScanned.UseVisualStyleBackColor = true;
            this.btnLoadScanned.Click += new System.EventHandler(this.btnLoadScanned_Click);
            // 
            // tpQueryResolution
            // 
            this.tpQueryResolution.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.tpQueryResolution.Controls.Add(this.scQrsMain);
            this.tpQueryResolution.Location = new System.Drawing.Point(4, 28);
            this.tpQueryResolution.Margin = new System.Windows.Forms.Padding(4);
            this.tpQueryResolution.Name = "tpQueryResolution";
            this.tpQueryResolution.Padding = new System.Windows.Forms.Padding(4);
            this.tpQueryResolution.Size = new System.Drawing.Size(1545, 707);
            this.tpQueryResolution.TabIndex = 3;
            this.tpQueryResolution.Text = "Query Resolution";
            // 
            // scQrsMain
            // 
            this.scQrsMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scQrsMain.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.scQrsMain.Location = new System.Drawing.Point(4, 4);
            this.scQrsMain.Margin = new System.Windows.Forms.Padding(4);
            this.scQrsMain.Name = "scQrsMain";
            // 
            // scQrsMain.Panel1
            // 
            this.scQrsMain.Panel1.Controls.Add(this.scQryRes);
            // 
            // scQrsMain.Panel2
            // 
            this.scQrsMain.Panel2.Controls.Add(this.scQrsLeft);
            this.scQrsMain.Panel2Collapsed = true;
            this.scQrsMain.Size = new System.Drawing.Size(1537, 699);
            this.scQrsMain.SplitterDistance = 1247;
            this.scQrsMain.SplitterWidth = 5;
            this.scQrsMain.TabIndex = 2;
            // 
            // scQryRes
            // 
            this.scQryRes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scQryRes.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.scQryRes.Location = new System.Drawing.Point(0, 0);
            this.scQryRes.Margin = new System.Windows.Forms.Padding(4);
            this.scQryRes.Name = "scQryRes";
            this.scQryRes.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // scQryRes.Panel1
            // 
            this.scQryRes.Panel1.Controls.Add(this.groupBox3);
            // 
            // scQryRes.Panel2
            // 
            this.scQryRes.Panel2.Controls.Add(this.groupBox7);
            this.scQryRes.Panel2.Controls.Add(this.groupBox5);
            this.scQryRes.Size = new System.Drawing.Size(1537, 699);
            this.scQryRes.SplitterDistance = 87;
            this.scQryRes.SplitterWidth = 5;
            this.scQryRes.TabIndex = 1;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnSearchQrsCandidate);
            this.groupBox3.Controls.Add(this.gbQrsCheckCandidate);
            this.groupBox3.Controls.Add(this.btnEnterUnscanned);
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(0, 0);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(1537, 87);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // btnSearchQrsCandidate
            // 
            this.btnSearchQrsCandidate.ForeColor = System.Drawing.Color.Black;
            this.btnSearchQrsCandidate.Location = new System.Drawing.Point(209, 15);
            this.btnSearchQrsCandidate.Margin = new System.Windows.Forms.Padding(4);
            this.btnSearchQrsCandidate.Name = "btnSearchQrsCandidate";
            this.btnSearchQrsCandidate.Size = new System.Drawing.Size(195, 64);
            this.btnSearchQrsCandidate.TabIndex = 2;
            this.btnSearchQrsCandidate.Text = "Check Candidate\'s Data";
            this.btnSearchQrsCandidate.UseVisualStyleBackColor = true;
            this.btnSearchQrsCandidate.Click += new System.EventHandler(this.btnSearchQrsCandidate_Click);
            // 
            // gbQrsCheckCandidate
            // 
            this.gbQrsCheckCandidate.Controls.Add(this.tableLayoutPanel8);
            this.gbQrsCheckCandidate.Controls.Add(this.cbQrsCheckShowUnscored);
            this.gbQrsCheckCandidate.Controls.Add(this.cbQrsCheckShowManuallyKeyed);
            this.gbQrsCheckCandidate.Controls.Add(this.btnQrsCheckClear);
            this.gbQrsCheckCandidate.Controls.Add(this.btnSearchCheckCandidate);
            this.gbQrsCheckCandidate.Controls.Add(this.lvQrsCheckCandidate);
            this.gbQrsCheckCandidate.Controls.Add(this.txtQrsCheckIndexNo);
            this.gbQrsCheckCandidate.Controls.Add(this.txtQrsCheckCentNo);
            this.gbQrsCheckCandidate.Controls.Add(this.txtQrsCheckExamYear);
            this.gbQrsCheckCandidate.Controls.Add(this.label27);
            this.gbQrsCheckCandidate.Controls.Add(this.label26);
            this.gbQrsCheckCandidate.Controls.Add(this.label25);
            this.gbQrsCheckCandidate.ForeColor = System.Drawing.Color.White;
            this.gbQrsCheckCandidate.Location = new System.Drawing.Point(8, 113);
            this.gbQrsCheckCandidate.Margin = new System.Windows.Forms.Padding(4);
            this.gbQrsCheckCandidate.Name = "gbQrsCheckCandidate";
            this.gbQrsCheckCandidate.Padding = new System.Windows.Forms.Padding(4);
            this.gbQrsCheckCandidate.Size = new System.Drawing.Size(1232, 539);
            this.gbQrsCheckCandidate.TabIndex = 1;
            this.gbQrsCheckCandidate.TabStop = false;
            this.gbQrsCheckCandidate.Text = "Check Candidate\'s Data";
            this.gbQrsCheckCandidate.Visible = false;
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 2;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.Controls.Add(this.btnQrsCheckShowAbsents, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.button3, 1, 0);
            this.tableLayoutPanel8.Controls.Add(this.button6, 0, 1);
            this.tableLayoutPanel8.Controls.Add(this.button7, 1, 1);
            this.tableLayoutPanel8.Location = new System.Drawing.Point(977, 18);
            this.tableLayoutPanel8.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 2;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(256, 94);
            this.tableLayoutPanel8.TabIndex = 9;
            // 
            // btnQrsCheckShowAbsents
            // 
            this.btnQrsCheckShowAbsents.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnQrsCheckShowAbsents.ForeColor = System.Drawing.Color.Black;
            this.btnQrsCheckShowAbsents.Location = new System.Drawing.Point(4, 4);
            this.btnQrsCheckShowAbsents.Margin = new System.Windows.Forms.Padding(4);
            this.btnQrsCheckShowAbsents.Name = "btnQrsCheckShowAbsents";
            this.btnQrsCheckShowAbsents.Size = new System.Drawing.Size(120, 39);
            this.btnQrsCheckShowAbsents.TabIndex = 8;
            this.btnQrsCheckShowAbsents.Text = "Show Absents";
            this.btnQrsCheckShowAbsents.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button3.Enabled = false;
            this.button3.ForeColor = System.Drawing.Color.Black;
            this.button3.Location = new System.Drawing.Point(132, 4);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(120, 39);
            this.button3.TabIndex = 8;
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button6.Enabled = false;
            this.button6.ForeColor = System.Drawing.Color.Black;
            this.button6.Location = new System.Drawing.Point(4, 51);
            this.button6.Margin = new System.Windows.Forms.Padding(4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(120, 39);
            this.button6.TabIndex = 8;
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button7.Enabled = false;
            this.button7.ForeColor = System.Drawing.Color.Black;
            this.button7.Location = new System.Drawing.Point(132, 51);
            this.button7.Margin = new System.Windows.Forms.Padding(4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(120, 39);
            this.button7.TabIndex = 8;
            this.button7.UseVisualStyleBackColor = true;
            // 
            // cbQrsCheckShowUnscored
            // 
            this.cbQrsCheckShowUnscored.AutoSize = true;
            this.cbQrsCheckShowUnscored.Location = new System.Drawing.Point(835, 55);
            this.cbQrsCheckShowUnscored.Margin = new System.Windows.Forms.Padding(4);
            this.cbQrsCheckShowUnscored.Name = "cbQrsCheckShowUnscored";
            this.cbQrsCheckShowUnscored.Size = new System.Drawing.Size(93, 21);
            this.cbQrsCheckShowUnscored.TabIndex = 7;
            this.cbQrsCheckShowUnscored.Text = "UnScored";
            this.cbQrsCheckShowUnscored.UseVisualStyleBackColor = true;
            this.cbQrsCheckShowUnscored.CheckedChanged += new System.EventHandler(this.cbQrsCheckShowManuallyKeyed_CheckedChanged);
            // 
            // cbQrsCheckShowManuallyKeyed
            // 
            this.cbQrsCheckShowManuallyKeyed.AutoSize = true;
            this.cbQrsCheckShowManuallyKeyed.Location = new System.Drawing.Point(835, 27);
            this.cbQrsCheckShowManuallyKeyed.Margin = new System.Windows.Forms.Padding(4);
            this.cbQrsCheckShowManuallyKeyed.Name = "cbQrsCheckShowManuallyKeyed";
            this.cbQrsCheckShowManuallyKeyed.Size = new System.Drawing.Size(130, 21);
            this.cbQrsCheckShowManuallyKeyed.TabIndex = 7;
            this.cbQrsCheckShowManuallyKeyed.Text = "Manually Keyed";
            this.cbQrsCheckShowManuallyKeyed.UseVisualStyleBackColor = true;
            this.cbQrsCheckShowManuallyKeyed.CheckedChanged += new System.EventHandler(this.cbQrsCheckShowManuallyKeyed_CheckedChanged);
            // 
            // btnQrsCheckClear
            // 
            this.btnQrsCheckClear.ForeColor = System.Drawing.Color.Black;
            this.btnQrsCheckClear.Location = new System.Drawing.Point(1284, 18);
            this.btnQrsCheckClear.Margin = new System.Windows.Forms.Padding(4);
            this.btnQrsCheckClear.Name = "btnQrsCheckClear";
            this.btnQrsCheckClear.Size = new System.Drawing.Size(95, 91);
            this.btnQrsCheckClear.TabIndex = 5;
            this.btnQrsCheckClear.Text = "Clear";
            this.btnQrsCheckClear.UseVisualStyleBackColor = true;
            this.btnQrsCheckClear.Click += new System.EventHandler(this.btnQrsCheckClear_Click);
            // 
            // btnSearchCheckCandidate
            // 
            this.btnSearchCheckCandidate.Enabled = false;
            this.btnSearchCheckCandidate.ForeColor = System.Drawing.Color.Black;
            this.btnSearchCheckCandidate.Location = new System.Drawing.Point(645, 23);
            this.btnSearchCheckCandidate.Margin = new System.Windows.Forms.Padding(4);
            this.btnSearchCheckCandidate.Name = "btnSearchCheckCandidate";
            this.btnSearchCheckCandidate.Size = new System.Drawing.Size(181, 91);
            this.btnSearchCheckCandidate.TabIndex = 4;
            this.btnSearchCheckCandidate.Text = "Search";
            this.btnSearchCheckCandidate.UseVisualStyleBackColor = true;
            this.btnSearchCheckCandidate.Click += new System.EventHandler(this.btnSearchCheckCandidate_Click);
            // 
            // lvQrsCheckCandidate
            // 
            this.lvQrsCheckCandidate.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader12,
            this.columnHeader13,
            this.columnHeader14,
            this.columnHeader15});
            this.lvQrsCheckCandidate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvQrsCheckCandidate.Location = new System.Drawing.Point(7, 122);
            this.lvQrsCheckCandidate.Margin = new System.Windows.Forms.Padding(4);
            this.lvQrsCheckCandidate.Name = "lvQrsCheckCandidate";
            this.lvQrsCheckCandidate.Size = new System.Drawing.Size(1380, 400);
            this.lvQrsCheckCandidate.TabIndex = 6;
            this.lvQrsCheckCandidate.TabStop = false;
            this.lvQrsCheckCandidate.UseCompatibleStateImageBehavior = false;
            this.lvQrsCheckCandidate.View = System.Windows.Forms.View.Details;
            this.lvQrsCheckCandidate.SelectedIndexChanged += new System.EventHandler(this.lvQrsCheckCandidate_SelectedIndexChanged);
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Exam Year";
            this.columnHeader7.Width = 100;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Centre No";
            this.columnHeader8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader8.Width = 100;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Index No";
            this.columnHeader9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader9.Width = 100;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Subject";
            this.columnHeader10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader10.Width = 100;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "sexCode";
            this.columnHeader11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Absent";
            this.columnHeader12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader12.Width = 80;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Data";
            this.columnHeader13.Width = 350;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "Keyed";
            this.columnHeader14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "Scored";
            this.columnHeader15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader15.Width = 70;
            // 
            // txtQrsCheckIndexNo
            // 
            this.txtQrsCheckIndexNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQrsCheckIndexNo.Location = new System.Drawing.Point(412, 57);
            this.txtQrsCheckIndexNo.Margin = new System.Windows.Forms.Padding(4);
            this.txtQrsCheckIndexNo.Name = "txtQrsCheckIndexNo";
            this.txtQrsCheckIndexNo.Size = new System.Drawing.Size(203, 38);
            this.txtQrsCheckIndexNo.TabIndex = 3;
            this.txtQrsCheckIndexNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtQrsCheckIndexNo.TextChanged += new System.EventHandler(this.txtQrsCheckIndexNo_TextChanged);
            // 
            // txtQrsCheckCentNo
            // 
            this.txtQrsCheckCentNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQrsCheckCentNo.Location = new System.Drawing.Point(175, 57);
            this.txtQrsCheckCentNo.Margin = new System.Windows.Forms.Padding(4);
            this.txtQrsCheckCentNo.Name = "txtQrsCheckCentNo";
            this.txtQrsCheckCentNo.Size = new System.Drawing.Size(203, 38);
            this.txtQrsCheckCentNo.TabIndex = 2;
            this.txtQrsCheckCentNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtQrsCheckCentNo.TextChanged += new System.EventHandler(this.txtQrsCheckCentNo_TextChanged);
            // 
            // txtQrsCheckExamYear
            // 
            this.txtQrsCheckExamYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQrsCheckExamYear.Location = new System.Drawing.Point(16, 57);
            this.txtQrsCheckExamYear.Margin = new System.Windows.Forms.Padding(4);
            this.txtQrsCheckExamYear.Name = "txtQrsCheckExamYear";
            this.txtQrsCheckExamYear.ReadOnly = true;
            this.txtQrsCheckExamYear.Size = new System.Drawing.Size(124, 38);
            this.txtQrsCheckExamYear.TabIndex = 1;
            this.txtQrsCheckExamYear.TabStop = false;
            this.txtQrsCheckExamYear.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(465, 32);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(95, 17);
            this.label27.TabIndex = 0;
            this.label27.Text = "Index Number";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(224, 32);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(104, 17);
            this.label26.TabIndex = 0;
            this.label26.Text = "Centre Number";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(40, 32);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(76, 17);
            this.label25.TabIndex = 0;
            this.label25.Text = "Exam Year";
            // 
            // btnEnterUnscanned
            // 
            this.btnEnterUnscanned.ForeColor = System.Drawing.Color.Black;
            this.btnEnterUnscanned.Location = new System.Drawing.Point(420, 15);
            this.btnEnterUnscanned.Margin = new System.Windows.Forms.Padding(4);
            this.btnEnterUnscanned.Name = "btnEnterUnscanned";
            this.btnEnterUnscanned.Size = new System.Drawing.Size(561, 64);
            this.btnEnterUnscanned.TabIndex = 0;
            this.btnEnterUnscanned.Text = "Enter Unscanned Sheets";
            this.btnEnterUnscanned.UseVisualStyleBackColor = true;
            this.btnEnterUnscanned.Click += new System.EventHandler(this.btnEnterUnscanned_Click);
            // 
            // button1
            // 
            this.button1.Enabled = false;
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(12, 15);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(192, 64);
            this.button1.TabIndex = 0;
            this.button1.Text = "Unscanned Centres";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.groupBox6);
            this.groupBox7.Controls.Add(this.groupBox4);
            this.groupBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox7.Location = new System.Drawing.Point(0, 0);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox7.Size = new System.Drawing.Size(1537, 607);
            this.groupBox7.TabIndex = 6;
            this.groupBox7.TabStop = false;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.scQrsData);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox6.Location = new System.Drawing.Point(4, 19);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox6.Size = new System.Drawing.Size(1529, 584);
            this.groupBox6.TabIndex = 5;
            this.groupBox6.TabStop = false;
            // 
            // scQrsData
            // 
            this.scQrsData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scQrsData.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.scQrsData.IsSplitterFixed = true;
            this.scQrsData.Location = new System.Drawing.Point(4, 19);
            this.scQrsData.Margin = new System.Windows.Forms.Padding(4);
            this.scQrsData.Name = "scQrsData";
            this.scQrsData.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // scQrsData.Panel1
            // 
            this.scQrsData.Panel1.Controls.Add(this.btnQrsShowKeyPad);
            this.scQrsData.Panel1.Controls.Add(this.rbQrsStartFromIndex);
            this.scQrsData.Panel1.Controls.Add(this.rbQrsStartFromCent);
            this.scQrsData.Panel1.Controls.Add(this.label23);
            this.scQrsData.Panel1.Controls.Add(this.label16);
            this.scQrsData.Panel1.Controls.Add(this.BtnQrsClear);
            this.scQrsData.Panel1.Controls.Add(this.btnQrsSaveData);
            this.scQrsData.Panel1.Controls.Add(this.cbQrsAbsent);
            this.scQrsData.Panel1.Controls.Add(this.txtQrsSubjCode);
            this.scQrsData.Panel1.Controls.Add(this.txtQrsIndexNumber);
            this.scQrsData.Panel1.Controls.Add(this.txtQrsCentreNumber);
            this.scQrsData.Panel1.Controls.Add(this.cbQrsSex);
            this.scQrsData.Panel1.Controls.Add(this.label18);
            this.scQrsData.Panel1.Controls.Add(this.label19);
            this.scQrsData.Panel1.Controls.Add(this.label21);
            this.scQrsData.Panel1.Controls.Add(this.txtQrsExamYear);
            this.scQrsData.Panel1.Controls.Add(this.label17);
            // 
            // scQrsData.Panel2
            // 
            this.scQrsData.Panel2.Controls.Add(this.rtbQrsDisplay);
            this.scQrsData.Panel2.Controls.Add(this.gbQrsKeypad);
            this.scQrsData.Panel2.Controls.Add(this.listView1);
            this.scQrsData.Panel2.Controls.Add(this.lblCurrentCaretPosition);
            this.scQrsData.Panel2.Controls.Add(this.lblCurrentQuestion);
            this.scQrsData.Panel2.Controls.Add(this.label22);
            this.scQrsData.Panel2.Controls.Add(this.label24);
            this.scQrsData.Panel2.Controls.Add(this.label20);
            this.scQrsData.Panel2.Controls.Add(this.txtQrsDataConfirm);
            this.scQrsData.Panel2.Controls.Add(this.txtQrsData);
            this.scQrsData.Size = new System.Drawing.Size(1521, 561);
            this.scQrsData.SplitterDistance = 25;
            this.scQrsData.TabIndex = 11;
            // 
            // btnQrsShowKeyPad
            // 
            this.btnQrsShowKeyPad.ForeColor = System.Drawing.Color.Black;
            this.btnQrsShowKeyPad.Location = new System.Drawing.Point(947, 48);
            this.btnQrsShowKeyPad.Name = "btnQrsShowKeyPad";
            this.btnQrsShowKeyPad.Size = new System.Drawing.Size(86, 38);
            this.btnQrsShowKeyPad.TabIndex = 11;
            this.btnQrsShowKeyPad.Text = "Show keypad";
            this.btnQrsShowKeyPad.UseVisualStyleBackColor = true;
            this.btnQrsShowKeyPad.Click += new System.EventHandler(this.btnQrsShowKeyPad_Click);
            // 
            // rbQrsStartFromIndex
            // 
            this.rbQrsStartFromIndex.AutoSize = true;
            this.rbQrsStartFromIndex.Location = new System.Drawing.Point(319, 67);
            this.rbQrsStartFromIndex.Name = "rbQrsStartFromIndex";
            this.rbQrsStartFromIndex.Size = new System.Drawing.Size(17, 16);
            this.rbQrsStartFromIndex.TabIndex = 10;
            this.rbQrsStartFromIndex.UseVisualStyleBackColor = true;
            // 
            // rbQrsStartFromCent
            // 
            this.rbQrsStartFromCent.AutoSize = true;
            this.rbQrsStartFromCent.Checked = true;
            this.rbQrsStartFromCent.Location = new System.Drawing.Point(194, 67);
            this.rbQrsStartFromCent.Name = "rbQrsStartFromCent";
            this.rbQrsStartFromCent.Size = new System.Drawing.Size(17, 16);
            this.rbQrsStartFromCent.TabIndex = 10;
            this.rbQrsStartFromCent.TabStop = true;
            this.rbQrsStartFromCent.UseVisualStyleBackColor = true;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(89, 67);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(78, 17);
            this.label23.TabIndex = 9;
            this.label23.Text = "Start From:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(37, 5);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(76, 17);
            this.label16.TabIndex = 4;
            this.label16.Text = "Exam Year";
            // 
            // BtnQrsClear
            // 
            this.BtnQrsClear.ForeColor = System.Drawing.Color.Black;
            this.BtnQrsClear.Location = new System.Drawing.Point(945, 5);
            this.BtnQrsClear.Name = "BtnQrsClear";
            this.BtnQrsClear.Size = new System.Drawing.Size(88, 40);
            this.BtnQrsClear.TabIndex = 8;
            this.BtnQrsClear.Text = "Clear";
            this.BtnQrsClear.UseVisualStyleBackColor = true;
            this.BtnQrsClear.Click += new System.EventHandler(this.BtnQrsClear_Click);
            // 
            // btnQrsSaveData
            // 
            this.btnQrsSaveData.ForeColor = System.Drawing.Color.Black;
            this.btnQrsSaveData.Location = new System.Drawing.Point(786, 5);
            this.btnQrsSaveData.Name = "btnQrsSaveData";
            this.btnQrsSaveData.Size = new System.Drawing.Size(153, 81);
            this.btnQrsSaveData.TabIndex = 8;
            this.btnQrsSaveData.Text = "Save";
            this.btnQrsSaveData.UseVisualStyleBackColor = true;
            this.btnQrsSaveData.Click += new System.EventHandler(this.btnQrsSaveData_Click);
            // 
            // cbQrsAbsent
            // 
            this.cbQrsAbsent.AutoSize = true;
            this.cbQrsAbsent.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbQrsAbsent.Location = new System.Drawing.Point(598, 28);
            this.cbQrsAbsent.Name = "cbQrsAbsent";
            this.cbQrsAbsent.Size = new System.Drawing.Size(121, 35);
            this.cbQrsAbsent.TabIndex = 5;
            this.cbQrsAbsent.Text = "Absent";
            this.cbQrsAbsent.UseVisualStyleBackColor = true;
            this.cbQrsAbsent.CheckedChanged += new System.EventHandler(this.cbQrsAbsent_CheckedChanged);
            // 
            // txtQrsSubjCode
            // 
            this.txtQrsSubjCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQrsSubjCode.Location = new System.Drawing.Point(401, 27);
            this.txtQrsSubjCode.Name = "txtQrsSubjCode";
            this.txtQrsSubjCode.Size = new System.Drawing.Size(74, 38);
            this.txtQrsSubjCode.TabIndex = 3;
            this.txtQrsSubjCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtQrsSubjCode.TextChanged += new System.EventHandler(this.txtQrsSubjCode_TextChanged);
            this.txtQrsSubjCode.Leave += new System.EventHandler(this.txtQrsSubjCode_Leave);
            // 
            // txtQrsIndexNumber
            // 
            this.txtQrsIndexNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQrsIndexNumber.Location = new System.Drawing.Point(276, 27);
            this.txtQrsIndexNumber.Name = "txtQrsIndexNumber";
            this.txtQrsIndexNumber.Size = new System.Drawing.Size(100, 38);
            this.txtQrsIndexNumber.TabIndex = 2;
            this.txtQrsIndexNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtQrsIndexNumber.TextChanged += new System.EventHandler(this.txtQrsIndexNumber_TextChanged);
            // 
            // txtQrsCentreNumber
            // 
            this.txtQrsCentreNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQrsCentreNumber.Location = new System.Drawing.Point(151, 27);
            this.txtQrsCentreNumber.Name = "txtQrsCentreNumber";
            this.txtQrsCentreNumber.Size = new System.Drawing.Size(100, 38);
            this.txtQrsCentreNumber.TabIndex = 1;
            this.txtQrsCentreNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtQrsCentreNumber.TextChanged += new System.EventHandler(this.txtQrsCentreNumber_TextChanged);
            // 
            // cbQrsSex
            // 
            this.cbQrsSex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbQrsSex.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbQrsSex.FormattingEnabled = true;
            this.cbQrsSex.Items.AddRange(new object[] {
            "F",
            "M"});
            this.cbQrsSex.Location = new System.Drawing.Point(500, 27);
            this.cbQrsSex.Name = "cbQrsSex";
            this.cbQrsSex.Size = new System.Drawing.Size(73, 39);
            this.cbQrsSex.TabIndex = 4;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(162, 5);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(104, 17);
            this.label18.TabIndex = 4;
            this.label18.Text = "Centre Number";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(524, 5);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(62, 17);
            this.label19.TabIndex = 6;
            this.label19.Text = "sexCode";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(402, 5);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(92, 17);
            this.label21.TabIndex = 4;
            this.label21.Text = "Subject Code";
            // 
            // txtQrsExamYear
            // 
            this.txtQrsExamYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQrsExamYear.Location = new System.Drawing.Point(7, 27);
            this.txtQrsExamYear.Name = "txtQrsExamYear";
            this.txtQrsExamYear.ReadOnly = true;
            this.txtQrsExamYear.Size = new System.Drawing.Size(119, 38);
            this.txtQrsExamYear.TabIndex = 0;
            this.txtQrsExamYear.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(290, 5);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(95, 17);
            this.label17.TabIndex = 4;
            this.label17.Text = "Index Number";
            // 
            // gbQrsKeypad
            // 
            this.gbQrsKeypad.Controls.Add(this.tableLayoutPanel7);
            this.gbQrsKeypad.Location = new System.Drawing.Point(842, 3);
            this.gbQrsKeypad.Name = "gbQrsKeypad";
            this.gbQrsKeypad.Size = new System.Drawing.Size(200, 273);
            this.gbQrsKeypad.TabIndex = 8;
            this.gbQrsKeypad.TabStop = false;
            this.gbQrsKeypad.Visible = false;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Controls.Add(this.btnQrsMulti, 1, 2);
            this.tableLayoutPanel7.Controls.Add(this.btnQrsSpace, 0, 2);
            this.tableLayoutPanel7.Controls.Add(this.btnQrsD, 1, 1);
            this.tableLayoutPanel7.Controls.Add(this.btnQrsC, 0, 1);
            this.tableLayoutPanel7.Controls.Add(this.btnQrsB, 1, 0);
            this.tableLayoutPanel7.Controls.Add(this.btnQrsA, 0, 0);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(3, 18);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 3;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(194, 252);
            this.tableLayoutPanel7.TabIndex = 0;
            // 
            // btnQrsMulti
            // 
            this.btnQrsMulti.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnQrsMulti.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQrsMulti.ForeColor = System.Drawing.Color.Black;
            this.btnQrsMulti.Location = new System.Drawing.Point(100, 171);
            this.btnQrsMulti.Name = "btnQrsMulti";
            this.btnQrsMulti.Size = new System.Drawing.Size(91, 78);
            this.btnQrsMulti.TabIndex = 5;
            this.btnQrsMulti.Text = "<";
            this.btnQrsMulti.UseVisualStyleBackColor = true;
            this.btnQrsMulti.Click += new System.EventHandler(this.UpdateCurrentQrsTextBox);
            // 
            // btnQrsSpace
            // 
            this.btnQrsSpace.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnQrsSpace.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQrsSpace.ForeColor = System.Drawing.Color.Black;
            this.btnQrsSpace.Location = new System.Drawing.Point(3, 171);
            this.btnQrsSpace.Name = "btnQrsSpace";
            this.btnQrsSpace.Size = new System.Drawing.Size(91, 78);
            this.btnQrsSpace.TabIndex = 4;
            this.btnQrsSpace.Text = " ";
            this.btnQrsSpace.UseVisualStyleBackColor = true;
            this.btnQrsSpace.Click += new System.EventHandler(this.UpdateCurrentQrsTextBox);
            // 
            // btnQrsD
            // 
            this.btnQrsD.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnQrsD.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQrsD.ForeColor = System.Drawing.Color.Black;
            this.btnQrsD.Location = new System.Drawing.Point(100, 87);
            this.btnQrsD.Name = "btnQrsD";
            this.btnQrsD.Size = new System.Drawing.Size(91, 78);
            this.btnQrsD.TabIndex = 3;
            this.btnQrsD.Text = "D";
            this.btnQrsD.UseVisualStyleBackColor = true;
            this.btnQrsD.Click += new System.EventHandler(this.UpdateCurrentQrsTextBox);
            // 
            // btnQrsC
            // 
            this.btnQrsC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnQrsC.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQrsC.ForeColor = System.Drawing.Color.Black;
            this.btnQrsC.Location = new System.Drawing.Point(3, 87);
            this.btnQrsC.Name = "btnQrsC";
            this.btnQrsC.Size = new System.Drawing.Size(91, 78);
            this.btnQrsC.TabIndex = 2;
            this.btnQrsC.Text = "C";
            this.btnQrsC.UseVisualStyleBackColor = true;
            this.btnQrsC.Click += new System.EventHandler(this.UpdateCurrentQrsTextBox);
            // 
            // btnQrsB
            // 
            this.btnQrsB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnQrsB.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQrsB.ForeColor = System.Drawing.Color.Black;
            this.btnQrsB.Location = new System.Drawing.Point(100, 3);
            this.btnQrsB.Name = "btnQrsB";
            this.btnQrsB.Size = new System.Drawing.Size(91, 78);
            this.btnQrsB.TabIndex = 1;
            this.btnQrsB.Text = "B";
            this.btnQrsB.UseVisualStyleBackColor = true;
            this.btnQrsB.Click += new System.EventHandler(this.UpdateCurrentQrsTextBox);
            // 
            // btnQrsA
            // 
            this.btnQrsA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnQrsA.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQrsA.ForeColor = System.Drawing.Color.Black;
            this.btnQrsA.Location = new System.Drawing.Point(3, 3);
            this.btnQrsA.Name = "btnQrsA";
            this.btnQrsA.Size = new System.Drawing.Size(91, 78);
            this.btnQrsA.TabIndex = 0;
            this.btnQrsA.Text = "A";
            this.btnQrsA.UseVisualStyleBackColor = true;
            this.btnQrsA.Click += new System.EventHandler(this.UpdateCurrentQrsTextBox);
            // 
            // listView1
            // 
            this.listView1.Location = new System.Drawing.Point(4, 143);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(828, 43);
            this.listView1.TabIndex = 7;
            this.listView1.TabStop = false;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.List;
            this.listView1.Visible = false;
            // 
            // lblCurrentCaretPosition
            // 
            this.lblCurrentCaretPosition.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentCaretPosition.Location = new System.Drawing.Point(85, 64);
            this.lblCurrentCaretPosition.Name = "lblCurrentCaretPosition";
            this.lblCurrentCaretPosition.Size = new System.Drawing.Size(100, 23);
            this.lblCurrentCaretPosition.TabIndex = 5;
            // 
            // lblCurrentQuestion
            // 
            this.lblCurrentQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentQuestion.Location = new System.Drawing.Point(485, 65);
            this.lblCurrentQuestion.Name = "lblCurrentQuestion";
            this.lblCurrentQuestion.Size = new System.Drawing.Size(100, 23);
            this.lblCurrentQuestion.TabIndex = 5;
            // 
            // label22
            // 
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(826, 21);
            this.label22.TabIndex = 4;
            this.label22.Text = "BE VERY CAREFUL AND ENTER THE DATA AS IT IS! ERRORS WILL NOT BE TOLERATED!!!";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(37, 71);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(55, 17);
            this.label24.TabIndex = 4;
            this.label24.Text = "Current";
            this.label24.Visible = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(363, 71);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(155, 17);
            this.label20.TabIndex = 4;
            this.label20.Text = "Next Question Number:";
            // 
            // txtQrsDataConfirm
            // 
            this.txtQrsDataConfirm.Font = new System.Drawing.Font("Courier New", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQrsDataConfirm.Location = new System.Drawing.Point(4, 95);
            this.txtQrsDataConfirm.Name = "txtQrsDataConfirm";
            this.txtQrsDataConfirm.Size = new System.Drawing.Size(828, 38);
            this.txtQrsDataConfirm.TabIndex = 7;
            this.txtQrsDataConfirm.TextChanged += new System.EventHandler(this.txtQrsData_TextChanged);
            this.txtQrsDataConfirm.Enter += new System.EventHandler(this.QrsTextBoxActive);
            // 
            // txtQrsData
            // 
            this.txtQrsData.Font = new System.Drawing.Font("Courier New", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQrsData.Location = new System.Drawing.Point(4, 24);
            this.txtQrsData.Name = "txtQrsData";
            this.txtQrsData.Size = new System.Drawing.Size(828, 38);
            this.txtQrsData.TabIndex = 6;
            this.txtQrsData.TextChanged += new System.EventHandler(this.txtQrsData_TextChanged);
            this.txtQrsData.Enter += new System.EventHandler(this.QrsTextBoxActive);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.textBox1);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.textBox2);
            this.groupBox4.Controls.Add(this.textBox3);
            this.groupBox4.Location = new System.Drawing.Point(138, 22);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(572, 100);
            this.groupBox4.TabIndex = 5;
            this.groupBox4.TabStop = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(52, 27);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(76, 17);
            this.label13.TabIndex = 4;
            this.label13.Text = "Exam Year";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(320, 27);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(95, 17);
            this.label15.TabIndex = 4;
            this.label15.Text = "Index Number";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(21, 56);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(119, 38);
            this.textBox1.TabIndex = 0;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(190, 27);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(104, 17);
            this.label14.TabIndex = 4;
            this.label14.Text = "Centre Number";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(170, 56);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 38);
            this.textBox2.TabIndex = 1;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(299, 56);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 38);
            this.textBox3.TabIndex = 2;
            // 
            // groupBox5
            // 
            this.groupBox5.Location = new System.Drawing.Point(134, 210);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(364, 131);
            this.groupBox5.TabIndex = 6;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "groupBox5";
            // 
            // scQrsLeft
            // 
            this.scQrsLeft.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scQrsLeft.Location = new System.Drawing.Point(0, 0);
            this.scQrsLeft.Name = "scQrsLeft";
            this.scQrsLeft.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.scQrsLeft.Size = new System.Drawing.Size(285, 699);
            this.scQrsLeft.SplitterDistance = 68;
            this.scQrsLeft.TabIndex = 0;
            // 
            // tpScore
            // 
            this.tpScore.BackColor = System.Drawing.Color.Olive;
            this.tpScore.Controls.Add(this.scScoreMain);
            this.tpScore.Location = new System.Drawing.Point(4, 28);
            this.tpScore.Name = "tpScore";
            this.tpScore.Size = new System.Drawing.Size(1545, 706);
            this.tpScore.TabIndex = 2;
            this.tpScore.Text = "Score";
            // 
            // scScoreMain
            // 
            this.scScoreMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scScoreMain.Location = new System.Drawing.Point(0, 0);
            this.scScoreMain.Name = "scScoreMain";
            this.scScoreMain.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // scScoreMain.Panel1
            // 
            this.scScoreMain.Panel1.Controls.Add(this.panel1);
            // 
            // scScoreMain.Panel2
            // 
            this.scScoreMain.Panel2.Controls.Add(this.scScore);
            this.scScoreMain.Size = new System.Drawing.Size(1545, 706);
            this.scScoreMain.SplitterDistance = 107;
            this.scScoreMain.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.scKeysView);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1545, 107);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // scKeysView
            // 
            this.scKeysView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scKeysView.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.scKeysView.Location = new System.Drawing.Point(0, 0);
            this.scKeysView.Name = "scKeysView";
            // 
            // scKeysView.Panel1
            // 
            this.scKeysView.Panel1.Controls.Add(this.lbAvailableKeys);
            this.scKeysView.Panel1.Controls.Add(this.btnLoadSelectedKey);
            this.scKeysView.Panel1.Controls.Add(this.cbKeysExamType);
            this.scKeysView.Panel1.Controls.Add(this.cbKeysExamYear);
            this.scKeysView.Panel1.Controls.Add(this.btnKeysRefresh);
            // 
            // scKeysView.Panel2
            // 
            this.scKeysView.Panel2.Controls.Add(this.scKeysViewDetails);
            this.scKeysView.Size = new System.Drawing.Size(1545, 107);
            this.scKeysView.SplitterDistance = 194;
            this.scKeysView.TabIndex = 0;
            // 
            // lbAvailableKeys
            // 
            this.lbAvailableKeys.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAvailableKeys.FormattingEnabled = true;
            this.lbAvailableKeys.ItemHeight = 25;
            this.lbAvailableKeys.Location = new System.Drawing.Point(7, 129);
            this.lbAvailableKeys.Name = "lbAvailableKeys";
            this.lbAvailableKeys.Size = new System.Drawing.Size(173, 279);
            this.lbAvailableKeys.Sorted = true;
            this.lbAvailableKeys.TabIndex = 3;
            this.lbAvailableKeys.SelectedIndexChanged += new System.EventHandler(this.lbAvailableKeys_SelectedIndexChanged);
            this.lbAvailableKeys.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lbAvailableKeys_MouseDoubleClick);
            // 
            // btnLoadSelectedKey
            // 
            this.btnLoadSelectedKey.Enabled = false;
            this.btnLoadSelectedKey.ForeColor = System.Drawing.Color.Black;
            this.btnLoadSelectedKey.Location = new System.Drawing.Point(0, 0);
            this.btnLoadSelectedKey.Name = "btnLoadSelectedKey";
            this.btnLoadSelectedKey.Size = new System.Drawing.Size(173, 50);
            this.btnLoadSelectedKey.TabIndex = 4;
            this.btnLoadSelectedKey.Text = "Load";
            this.btnLoadSelectedKey.UseVisualStyleBackColor = true;
            this.btnLoadSelectedKey.Click += new System.EventHandler(this.btnLoadSelectedKey_Click);
            // 
            // cbKeysExamType
            // 
            this.cbKeysExamType.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbKeysExamType.FormattingEnabled = true;
            this.cbKeysExamType.Location = new System.Drawing.Point(7, 95);
            this.cbKeysExamType.Name = "cbKeysExamType";
            this.cbKeysExamType.Size = new System.Drawing.Size(173, 33);
            this.cbKeysExamType.TabIndex = 2;
            this.cbKeysExamType.SelectedIndexChanged += new System.EventHandler(this.cbKeysExamType_SelectedIndexChanged);
            // 
            // cbKeysExamYear
            // 
            this.cbKeysExamYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbKeysExamYear.FormattingEnabled = true;
            this.cbKeysExamYear.Location = new System.Drawing.Point(7, 61);
            this.cbKeysExamYear.Name = "cbKeysExamYear";
            this.cbKeysExamYear.Size = new System.Drawing.Size(173, 33);
            this.cbKeysExamYear.TabIndex = 1;
            this.cbKeysExamYear.SelectedIndexChanged += new System.EventHandler(this.cbKeysExamYear_SelectedIndexChanged);
            // 
            // btnKeysRefresh
            // 
            this.btnKeysRefresh.ForeColor = System.Drawing.Color.Black;
            this.btnKeysRefresh.Location = new System.Drawing.Point(7, 4);
            this.btnKeysRefresh.Name = "btnKeysRefresh";
            this.btnKeysRefresh.Size = new System.Drawing.Size(173, 50);
            this.btnKeysRefresh.TabIndex = 0;
            this.btnKeysRefresh.Text = "Refresh";
            this.btnKeysRefresh.UseVisualStyleBackColor = true;
            this.btnKeysRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // scKeysViewDetails
            // 
            this.scKeysViewDetails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scKeysViewDetails.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.scKeysViewDetails.Location = new System.Drawing.Point(0, 0);
            this.scKeysViewDetails.Name = "scKeysViewDetails";
            this.scKeysViewDetails.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // scKeysViewDetails.Panel1
            // 
            this.scKeysViewDetails.Panel1.Controls.Add(this.rtbKeysView);
            // 
            // scKeysViewDetails.Panel2
            // 
            this.scKeysViewDetails.Panel2.Controls.Add(this.tableLayoutPanel2);
            this.scKeysViewDetails.Size = new System.Drawing.Size(1347, 107);
            this.scKeysViewDetails.SplitterDistance = 67;
            this.scKeysViewDetails.TabIndex = 0;
            // 
            // rtbKeysView
            // 
            this.rtbKeysView.DetectUrls = false;
            this.rtbKeysView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbKeysView.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbKeysView.Location = new System.Drawing.Point(0, 0);
            this.rtbKeysView.Name = "rtbKeysView";
            this.rtbKeysView.ReadOnly = true;
            this.rtbKeysView.Size = new System.Drawing.Size(1347, 67);
            this.rtbKeysView.TabIndex = 0;
            this.rtbKeysView.Text = "";
            this.rtbKeysView.WordWrap = false;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 6;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel6, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel5, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel4, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 3, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1347, 36);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 3;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel6.Controls.Add(this.button9, 2, 0);
            this.tableLayoutPanel6.Controls.Add(this.label12, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.button10, 1, 0);
            this.tableLayoutPanel6.Location = new System.Drawing.Point(451, 3);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(153, 30);
            this.tableLayoutPanel6.TabIndex = 3;
            this.tableLayoutPanel6.Visible = false;
            // 
            // button9
            // 
            this.button9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.Black;
            this.button9.Location = new System.Drawing.Point(117, 3);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(33, 24);
            this.button9.TabIndex = 2;
            this.button9.Text = "+";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Location = new System.Drawing.Point(3, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(70, 30);
            this.label12.TabIndex = 0;
            this.label12.Text = "Zoom";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // button10
            // 
            this.button10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.Black;
            this.button10.Location = new System.Drawing.Point(79, 3);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(32, 24);
            this.button10.TabIndex = 1;
            this.button10.Text = "-";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 3;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel5.Controls.Add(this.label11, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.nupRows, 1, 0);
            this.tableLayoutPanel5.Location = new System.Drawing.Point(227, 3);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(153, 30);
            this.tableLayoutPanel5.TabIndex = 2;
            // 
            // label11
            // 
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Location = new System.Drawing.Point(3, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(70, 30);
            this.label11.TabIndex = 0;
            this.label11.Text = "Rows";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // nupRows
            // 
            this.tableLayoutPanel5.SetColumnSpan(this.nupRows, 2);
            this.nupRows.Dock = System.Windows.Forms.DockStyle.Fill;
            this.nupRows.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nupRows.Increment = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nupRows.Location = new System.Drawing.Point(79, 3);
            this.nupRows.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nupRows.Name = "nupRows";
            this.nupRows.Size = new System.Drawing.Size(71, 38);
            this.nupRows.TabIndex = 1;
            this.nupRows.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 3;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel4.Controls.Add(this.btnScrollKeysRight, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.label10, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.btnScrollKeysLeft, 1, 0);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(153, 30);
            this.tableLayoutPanel4.TabIndex = 1;
            // 
            // btnScrollKeysRight
            // 
            this.btnScrollKeysRight.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnScrollKeysRight.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnScrollKeysRight.ForeColor = System.Drawing.Color.Black;
            this.btnScrollKeysRight.Location = new System.Drawing.Point(117, 3);
            this.btnScrollKeysRight.Name = "btnScrollKeysRight";
            this.btnScrollKeysRight.Size = new System.Drawing.Size(33, 24);
            this.btnScrollKeysRight.TabIndex = 2;
            this.btnScrollKeysRight.Text = ">";
            this.btnScrollKeysRight.UseVisualStyleBackColor = true;
            this.btnScrollKeysRight.Click += new System.EventHandler(this.btnScrollKeysRight_Click);
            // 
            // label10
            // 
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Location = new System.Drawing.Point(3, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(70, 30);
            this.label10.TabIndex = 0;
            this.label10.Text = "Scroll";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnScrollKeysLeft
            // 
            this.btnScrollKeysLeft.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnScrollKeysLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnScrollKeysLeft.ForeColor = System.Drawing.Color.Black;
            this.btnScrollKeysLeft.Location = new System.Drawing.Point(79, 3);
            this.btnScrollKeysLeft.Name = "btnScrollKeysLeft";
            this.btnScrollKeysLeft.Size = new System.Drawing.Size(32, 24);
            this.btnScrollKeysLeft.TabIndex = 1;
            this.btnScrollKeysLeft.Text = "<";
            this.btnScrollKeysLeft.UseVisualStyleBackColor = true;
            this.btnScrollKeysLeft.Click += new System.EventHandler(this.btnScrollKeysLeft_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel3.Controls.Add(this.btnKeysZoomPlus, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.label9, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.btnKeysZoomMinus, 1, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(675, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(153, 30);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // btnKeysZoomPlus
            // 
            this.btnKeysZoomPlus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnKeysZoomPlus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKeysZoomPlus.ForeColor = System.Drawing.Color.Black;
            this.btnKeysZoomPlus.Location = new System.Drawing.Point(117, 3);
            this.btnKeysZoomPlus.Name = "btnKeysZoomPlus";
            this.btnKeysZoomPlus.Size = new System.Drawing.Size(33, 24);
            this.btnKeysZoomPlus.TabIndex = 2;
            this.btnKeysZoomPlus.Text = "+";
            this.btnKeysZoomPlus.UseVisualStyleBackColor = true;
            this.btnKeysZoomPlus.Click += new System.EventHandler(this.btnKeysZoomPlus_Click);
            // 
            // label9
            // 
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Location = new System.Drawing.Point(3, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(70, 30);
            this.label9.TabIndex = 0;
            this.label9.Text = "Zoom";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnKeysZoomMinus
            // 
            this.btnKeysZoomMinus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnKeysZoomMinus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKeysZoomMinus.ForeColor = System.Drawing.Color.Black;
            this.btnKeysZoomMinus.Location = new System.Drawing.Point(79, 3);
            this.btnKeysZoomMinus.Name = "btnKeysZoomMinus";
            this.btnKeysZoomMinus.Size = new System.Drawing.Size(32, 24);
            this.btnKeysZoomMinus.TabIndex = 1;
            this.btnKeysZoomMinus.Text = "-";
            this.btnKeysZoomMinus.UseVisualStyleBackColor = true;
            this.btnKeysZoomMinus.Click += new System.EventHandler(this.btnKeysZoomMinus_Click);
            // 
            // scScore
            // 
            this.scScore.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scScore.Location = new System.Drawing.Point(0, 0);
            this.scScore.Name = "scScore";
            this.scScore.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // scScore.Panel1
            // 
            this.scScore.Panel1.Controls.Add(this.btnShowScore);
            // 
            // scScore.Panel2
            // 
            this.scScore.Panel2.Controls.Add(this.scScoreMid);
            this.scScore.Size = new System.Drawing.Size(1545, 595);
            this.scScore.SplitterDistance = 25;
            this.scScore.TabIndex = 2;
            this.scScore.Visible = false;
            // 
            // btnShowScore
            // 
            this.btnShowScore.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnShowScore.Enabled = false;
            this.btnShowScore.Location = new System.Drawing.Point(0, 0);
            this.btnShowScore.Name = "btnShowScore";
            this.btnShowScore.Size = new System.Drawing.Size(1545, 32);
            this.btnShowScore.TabIndex = 0;
            this.btnShowScore.UseVisualStyleBackColor = true;
            this.btnShowScore.Click += new System.EventHandler(this.btnShowScore_Click);
            // 
            // scScoreMid
            // 
            this.scScoreMid.Location = new System.Drawing.Point(4, 7);
            this.scScoreMid.Name = "scScoreMid";
            // 
            // scScoreMid.Panel1
            // 
            this.scScoreMid.Panel1.Controls.Add(this.scScoreLeftMid);
            // 
            // scScoreMid.Panel2
            // 
            this.scScoreMid.Panel2.Controls.Add(this.splitContainer6);
            this.scScoreMid.Size = new System.Drawing.Size(1189, 497);
            this.scScoreMid.SplitterDistance = 792;
            this.scScoreMid.TabIndex = 0;
            // 
            // scScoreLeftMid
            // 
            this.scScoreLeftMid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scScoreLeftMid.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.scScoreLeftMid.Location = new System.Drawing.Point(0, 0);
            this.scScoreLeftMid.Name = "scScoreLeftMid";
            this.scScoreLeftMid.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // scScoreLeftMid.Panel1
            // 
            this.scScoreLeftMid.Panel1.Controls.Add(this.scScoreLeft);
            // 
            // scScoreLeftMid.Panel2
            // 
            this.scScoreLeftMid.Panel2.Controls.Add(this.pgScoring);
            this.scScoreLeftMid.Size = new System.Drawing.Size(792, 497);
            this.scScoreLeftMid.SplitterDistance = 459;
            this.scScoreLeftMid.TabIndex = 0;
            // 
            // scScoreLeft
            // 
            this.scScoreLeft.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scScoreLeft.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.scScoreLeft.Location = new System.Drawing.Point(0, 0);
            this.scScoreLeft.Name = "scScoreLeft";
            // 
            // scScoreLeft.Panel1
            // 
            this.scScoreLeft.Panel1.Controls.Add(this.gbScoreOptions);
            this.scScoreLeft.Panel1.Controls.Add(this.btnRefresh);
            this.scScoreLeft.Panel1.Controls.Add(this.btnLoadKeys);
            this.scScoreLeft.Panel1.Controls.Add(this.cbScoreExamType);
            this.scScoreLeft.Panel1.Controls.Add(this.label8);
            this.scScoreLeft.Panel1.Controls.Add(this.cbScoreExamYear);
            this.scScoreLeft.Panel1.Controls.Add(this.label7);
            // 
            // scScoreLeft.Panel2
            // 
            this.scScoreLeft.Panel2.Controls.Add(this.lvScoringKeys);
            this.scScoreLeft.Size = new System.Drawing.Size(792, 459);
            this.scScoreLeft.SplitterDistance = 143;
            this.scScoreLeft.TabIndex = 1;
            // 
            // gbScoreOptions
            // 
            this.gbScoreOptions.Controls.Add(this.cbScoreblankAbsentData);
            this.gbScoreOptions.ForeColor = System.Drawing.Color.White;
            this.gbScoreOptions.Location = new System.Drawing.Point(7, 320);
            this.gbScoreOptions.Name = "gbScoreOptions";
            this.gbScoreOptions.Size = new System.Drawing.Size(125, 136);
            this.gbScoreOptions.TabIndex = 8;
            this.gbScoreOptions.TabStop = false;
            this.gbScoreOptions.Text = "Score Options";
            // 
            // cbScoreblankAbsentData
            // 
            this.cbScoreblankAbsentData.Location = new System.Drawing.Point(8, 15);
            this.cbScoreblankAbsentData.Name = "cbScoreblankAbsentData";
            this.cbScoreblankAbsentData.Size = new System.Drawing.Size(104, 40);
            this.cbScoreblankAbsentData.TabIndex = 0;
            this.cbScoreblankAbsentData.Text = "Score blank absent and data";
            this.cbScoreblankAbsentData.UseVisualStyleBackColor = true;
            this.cbScoreblankAbsentData.CheckedChanged += new System.EventHandler(this.cbScoreblankAbsentData_CheckedChanged);
            // 
            // btnRefresh
            // 
            this.btnRefresh.ForeColor = System.Drawing.Color.Black;
            this.btnRefresh.Location = new System.Drawing.Point(11, 13);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(121, 44);
            this.btnRefresh.TabIndex = 7;
            this.btnRefresh.Text = "&Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnLoadKeys
            // 
            this.btnLoadKeys.ForeColor = System.Drawing.Color.Black;
            this.btnLoadKeys.Location = new System.Drawing.Point(11, 191);
            this.btnLoadKeys.Name = "btnLoadKeys";
            this.btnLoadKeys.Size = new System.Drawing.Size(121, 65);
            this.btnLoadKeys.TabIndex = 7;
            this.btnLoadKeys.Text = "&Load";
            this.btnLoadKeys.UseVisualStyleBackColor = true;
            this.btnLoadKeys.Visible = false;
            this.btnLoadKeys.Click += new System.EventHandler(this.btnLoadKeys_Click);
            // 
            // cbScoreExamType
            // 
            this.cbScoreExamType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbScoreExamType.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbScoreExamType.FormattingEnabled = true;
            this.cbScoreExamType.Location = new System.Drawing.Point(11, 149);
            this.cbScoreExamType.Name = "cbScoreExamType";
            this.cbScoreExamType.Size = new System.Drawing.Size(121, 33);
            this.cbScoreExamType.Sorted = true;
            this.cbScoreExamType.TabIndex = 1;
            this.cbScoreExamType.SelectedIndexChanged += new System.EventHandler(this.cbScoreExamType_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(11, 122);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(121, 29);
            this.label8.TabIndex = 0;
            this.label8.Text = "Exam Type";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // cbScoreExamYear
            // 
            this.cbScoreExamYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbScoreExamYear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbScoreExamYear.FormattingEnabled = true;
            this.cbScoreExamYear.Location = new System.Drawing.Point(11, 86);
            this.cbScoreExamYear.Name = "cbScoreExamYear";
            this.cbScoreExamYear.Size = new System.Drawing.Size(121, 33);
            this.cbScoreExamYear.TabIndex = 1;
            this.cbScoreExamYear.SelectedIndexChanged += new System.EventHandler(this.cbScoreExamYear_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(11, 60);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(121, 23);
            this.label7.TabIndex = 0;
            this.label7.Text = "Exam Year";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // lvScoringKeys
            // 
            this.lvScoringKeys.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.lvScoringKeys.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.chCsdSubjCode,
            this.chExamYear,
            this.chNoOfItems,
            this.chKeyData});
            this.lvScoringKeys.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvScoringKeys.Font = new System.Drawing.Font("Courier New", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvScoringKeys.FullRowSelect = true;
            this.lvScoringKeys.Location = new System.Drawing.Point(0, 0);
            this.lvScoringKeys.Name = "lvScoringKeys";
            this.lvScoringKeys.Size = new System.Drawing.Size(645, 459);
            this.lvScoringKeys.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this.lvScoringKeys.TabIndex = 0;
            this.lvScoringKeys.UseCompatibleStateImageBehavior = false;
            this.lvScoringKeys.View = System.Windows.Forms.View.Details;
            // 
            // chCsdSubjCode
            // 
            this.chCsdSubjCode.Text = "CsdSubjCode";
            this.chCsdSubjCode.Width = 100;
            // 
            // chExamYear
            // 
            this.chExamYear.Text = "examYear";
            this.chExamYear.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.chExamYear.Width = 90;
            // 
            // chNoOfItems
            // 
            this.chNoOfItems.Text = "No Of Items";
            this.chNoOfItems.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.chNoOfItems.Width = 100;
            // 
            // chKeyData
            // 
            this.chKeyData.Text = "Data";
            this.chKeyData.Width = 500;
            // 
            // pgScoring
            // 
            this.pgScoring.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pgScoring.Location = new System.Drawing.Point(0, 0);
            this.pgScoring.Name = "pgScoring";
            this.pgScoring.Size = new System.Drawing.Size(792, 34);
            this.pgScoring.TabIndex = 0;
            // 
            // splitContainer6
            // 
            this.splitContainer6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer6.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitContainer6.Location = new System.Drawing.Point(0, 0);
            this.splitContainer6.Name = "splitContainer6";
            this.splitContainer6.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer6.Panel1
            // 
            this.splitContainer6.Panel1.Controls.Add(this.rtbScoreDisplay);
            // 
            // splitContainer6.Panel2
            // 
            this.splitContainer6.Panel2.Controls.Add(this.tableLayoutPanel1);
            this.splitContainer6.Size = new System.Drawing.Size(393, 497);
            this.splitContainer6.SplitterDistance = 323;
            this.splitContainer6.TabIndex = 0;
            // 
            // rtbScoreDisplay
            // 
            this.rtbScoreDisplay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbScoreDisplay.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbScoreDisplay.Location = new System.Drawing.Point(0, 0);
            this.rtbScoreDisplay.Name = "rtbScoreDisplay";
            this.rtbScoreDisplay.Size = new System.Drawing.Size(393, 323);
            this.rtbScoreDisplay.TabIndex = 0;
            this.rtbScoreDisplay.Text = "";
            this.rtbScoreDisplay.WordWrap = false;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Controls.Add(this.btnExitScore, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.button8, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.button5, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.button4, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnView, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnScoreMissing, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnScoreSelected, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.Padding = new System.Windows.Forms.Padding(5);
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(393, 170);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // btnExitScore
            // 
            this.btnExitScore.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnExitScore.ForeColor = System.Drawing.Color.Black;
            this.btnExitScore.Location = new System.Drawing.Point(262, 114);
            this.btnExitScore.Name = "btnExitScore";
            this.btnExitScore.Size = new System.Drawing.Size(123, 48);
            this.btnExitScore.TabIndex = 8;
            this.btnExitScore.Text = "E&xit";
            this.btnExitScore.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button8.ForeColor = System.Drawing.Color.Black;
            this.button8.Location = new System.Drawing.Point(135, 114);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(121, 48);
            this.button8.TabIndex = 7;
            this.button8.Text = "button8";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button5.ForeColor = System.Drawing.Color.Black;
            this.button5.Location = new System.Drawing.Point(135, 61);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(121, 47);
            this.button5.TabIndex = 4;
            this.button5.Text = "button5";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button4.ForeColor = System.Drawing.Color.Black;
            this.button4.Location = new System.Drawing.Point(8, 61);
            this.button4.Name = "button4";
            this.tableLayoutPanel1.SetRowSpan(this.button4, 2);
            this.button4.Size = new System.Drawing.Size(121, 101);
            this.button4.TabIndex = 3;
            this.button4.Text = "Score All";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // btnView
            // 
            this.btnView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnView.ForeColor = System.Drawing.Color.Black;
            this.btnView.Location = new System.Drawing.Point(262, 8);
            this.btnView.Name = "btnView";
            this.btnView.Size = new System.Drawing.Size(123, 47);
            this.btnView.TabIndex = 2;
            this.btnView.Text = "View";
            this.btnView.UseVisualStyleBackColor = true;
            // 
            // btnScoreMissing
            // 
            this.btnScoreMissing.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnScoreMissing.ForeColor = System.Drawing.Color.Black;
            this.btnScoreMissing.Location = new System.Drawing.Point(135, 8);
            this.btnScoreMissing.Name = "btnScoreMissing";
            this.btnScoreMissing.Size = new System.Drawing.Size(121, 47);
            this.btnScoreMissing.TabIndex = 1;
            this.btnScoreMissing.Text = "Score Missing";
            this.btnScoreMissing.UseVisualStyleBackColor = true;
            this.btnScoreMissing.Click += new System.EventHandler(this.btnScoreMissing_Click);
            // 
            // btnScoreSelected
            // 
            this.btnScoreSelected.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnScoreSelected.ForeColor = System.Drawing.Color.Black;
            this.btnScoreSelected.Location = new System.Drawing.Point(8, 8);
            this.btnScoreSelected.Name = "btnScoreSelected";
            this.btnScoreSelected.Size = new System.Drawing.Size(121, 47);
            this.btnScoreSelected.TabIndex = 0;
            this.btnScoreSelected.Text = "Score Selected";
            this.btnScoreSelected.UseVisualStyleBackColor = true;
            this.btnScoreSelected.Click += new System.EventHandler(this.btnScoreSelected_Click);
            // 
            // panelMain
            // 
            this.panelMain.AutoScroll = true;
            this.panelMain.Controls.Add(this.scMain);
            this.panelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMain.Location = new System.Drawing.Point(0, 0);
            this.panelMain.Margin = new System.Windows.Forms.Padding(4);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(1599, 941);
            this.panelMain.TabIndex = 1;
            // 
            // rtbQrsDisplay
            // 
            this.rtbQrsDisplay.Location = new System.Drawing.Point(4, 205);
            this.rtbQrsDisplay.Name = "rtbQrsDisplay";
            this.rtbQrsDisplay.Size = new System.Drawing.Size(828, 221);
            this.rtbQrsDisplay.TabIndex = 9;
            this.rtbQrsDisplay.Text = "";
            // 
            // frmObjScanning
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.Olive;
            this.ClientSize = new System.Drawing.Size(1599, 941);
            this.Controls.Add(this.panelMain);
            this.ForeColor = System.Drawing.Color.White;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(1181, 543);
            this.Name = "frmObjScanning";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "OMR Forms";
            this.Load += new System.EventHandler(this.frmObjScanning_Load);
            this.scMain.Panel1.ResumeLayout(false);
            this.scMain.Panel1.PerformLayout();
            this.scMain.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.scMain)).EndInit();
            this.scMain.ResumeLayout(false);
            this.tcOmr.ResumeLayout(false);
            this.tpOmrDataCapture.ResumeLayout(false);
            this.scMid.Panel1.ResumeLayout(false);
            this.scMid.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.scMid)).EndInit();
            this.scMid.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.scRight.Panel1.ResumeLayout(false);
            this.scRight.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.scRight)).EndInit();
            this.scRight.ResumeLayout(false);
            this.scTop.Panel1.ResumeLayout(false);
            this.scTop.Panel2.ResumeLayout(false);
            this.scTop.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scTop)).EndInit();
            this.scTop.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.scRtfDisplay.Panel1.ResumeLayout(false);
            this.scRtfDisplay.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.scRtfDisplay)).EndInit();
            this.scRtfDisplay.ResumeLayout(false);
            this.tpViewExport.ResumeLayout(false);
            this.gbViewExport.ResumeLayout(false);
            this.gbViewExport.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.cmslbCsdSubjCode.ResumeLayout(false);
            this.tpQueryResolution.ResumeLayout(false);
            this.scQrsMain.Panel1.ResumeLayout(false);
            this.scQrsMain.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.scQrsMain)).EndInit();
            this.scQrsMain.ResumeLayout(false);
            this.scQryRes.Panel1.ResumeLayout(false);
            this.scQryRes.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.scQryRes)).EndInit();
            this.scQryRes.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.gbQrsCheckCandidate.ResumeLayout(false);
            this.gbQrsCheckCandidate.PerformLayout();
            this.tableLayoutPanel8.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.scQrsData.Panel1.ResumeLayout(false);
            this.scQrsData.Panel1.PerformLayout();
            this.scQrsData.Panel2.ResumeLayout(false);
            this.scQrsData.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scQrsData)).EndInit();
            this.scQrsData.ResumeLayout(false);
            this.gbQrsKeypad.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scQrsLeft)).EndInit();
            this.scQrsLeft.ResumeLayout(false);
            this.tpScore.ResumeLayout(false);
            this.scScoreMain.Panel1.ResumeLayout(false);
            this.scScoreMain.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.scScoreMain)).EndInit();
            this.scScoreMain.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.scKeysView.Panel1.ResumeLayout(false);
            this.scKeysView.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.scKeysView)).EndInit();
            this.scKeysView.ResumeLayout(false);
            this.scKeysViewDetails.Panel1.ResumeLayout(false);
            this.scKeysViewDetails.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.scKeysViewDetails)).EndInit();
            this.scKeysViewDetails.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nupRows)).EndInit();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.scScore.Panel1.ResumeLayout(false);
            this.scScore.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.scScore)).EndInit();
            this.scScore.ResumeLayout(false);
            this.scScoreMid.Panel1.ResumeLayout(false);
            this.scScoreMid.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.scScoreMid)).EndInit();
            this.scScoreMid.ResumeLayout(false);
            this.scScoreLeftMid.Panel1.ResumeLayout(false);
            this.scScoreLeftMid.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.scScoreLeftMid)).EndInit();
            this.scScoreLeftMid.ResumeLayout(false);
            this.scScoreLeft.Panel1.ResumeLayout(false);
            this.scScoreLeft.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.scScoreLeft)).EndInit();
            this.scScoreLeft.ResumeLayout(false);
            this.gbScoreOptions.ResumeLayout(false);
            this.splitContainer6.Panel1.ResumeLayout(false);
            this.splitContainer6.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).EndInit();
            this.splitContainer6.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panelMain.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer scMain;
        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.TabControl tcOmr;
        private System.Windows.Forms.TabPage tpViewExport;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tpOmrDataCapture;
        private System.Windows.Forms.SplitContainer scMid;
        private System.Windows.Forms.SplitContainer scRight;
        private System.Windows.Forms.Button btnClean;
        private System.Windows.Forms.Button btnPasteDataFromCB;
        private System.Windows.Forms.Button btnClearRtbs;
        private System.Windows.Forms.SplitContainer scTop;
        private System.Windows.Forms.RichTextBox rtbData;
        private System.Windows.Forms.Label lblTotalLines;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblTotalCleanLines;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabPage tpScore;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbNanhaoData;
        private System.Windows.Forms.RadioButton rbDrsData;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.RichTextBox rtbOutput;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.ProgressBar pgStatus;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RichTextBox rtbDisplay;
        private System.Windows.Forms.Button btnSaveRtbDisplay;
        private System.Windows.Forms.Button btnClearRtbDisplay;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox gbViewExport;
        private System.Windows.Forms.Button btnLoadScanned;
        private System.Windows.Forms.ListBox lbCsdSubjCode;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExportAll;
        private System.Windows.Forms.Button btnExportSelected;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbExamYear;
        private System.Windows.Forms.ComboBox cbExams;
        private System.Windows.Forms.ListView lvSubjDetails;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ContextMenuStrip cmslbCsdSubjCode;
        private System.Windows.Forms.ToolStripMenuItem tsmiLoad;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem tmsiClear;
        private System.Windows.Forms.RichTextBox rtbRejectDisplay;
        private System.Windows.Forms.Button btnSaveScanned;
        private System.Windows.Forms.SplitContainer scRtfDisplay;
        private System.Windows.Forms.SplitContainer scScoreMid;
        private System.Windows.Forms.SplitContainer scScoreLeftMid;
        private System.Windows.Forms.ListView lvScoringKeys;
        private System.Windows.Forms.ProgressBar pgScoring;
        private System.Windows.Forms.SplitContainer splitContainer6;
        private System.Windows.Forms.RichTextBox rtbScoreDisplay;
        private System.Windows.Forms.ColumnHeader chCsdSubjCode;
        private System.Windows.Forms.ColumnHeader chExamYear;
        private System.Windows.Forms.ColumnHeader chNoOfItems;
        private System.Windows.Forms.ColumnHeader chKeyData;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button btnExitScore;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button btnView;
        private System.Windows.Forms.Button btnScoreMissing;
        private System.Windows.Forms.Button btnScoreSelected;
        private System.Windows.Forms.SplitContainer scScoreLeft;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnLoadKeys;
        private System.Windows.Forms.ComboBox cbScoreExamType;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cbScoreExamYear;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.SplitContainer scScoreMain;
        private System.Windows.Forms.SplitContainer scScore;
        private System.Windows.Forms.Button btnShowScore;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.SplitContainer scKeysView;
        private System.Windows.Forms.Button btnLoadSelectedKey;
        private System.Windows.Forms.ListBox lbAvailableKeys;
        private System.Windows.Forms.ComboBox cbKeysExamType;
        private System.Windows.Forms.ComboBox cbKeysExamYear;
        private System.Windows.Forms.Button btnKeysRefresh;
        private System.Windows.Forms.SplitContainer scKeysViewDetails;
        private System.Windows.Forms.RichTextBox rtbKeysView;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Button btnScrollKeysRight;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnScrollKeysLeft;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Button btnKeysZoomPlus;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnKeysZoomMinus;
        private System.Windows.Forms.NumericUpDown nupRows;
        private System.Windows.Forms.CheckBox cbAbsentCheck;
        private System.Windows.Forms.CheckBox cbLess15Check;
        private System.Windows.Forms.Button btnRefreshCentres;
        private System.Windows.Forms.Label lblSelectedSubject;
        private System.Windows.Forms.GroupBox gbScoreOptions;
        private System.Windows.Forms.CheckBox cbScoreblankAbsentData;
        private System.Windows.Forms.TabPage tpQueryResolution;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.SplitContainer scQryRes;
        private System.Windows.Forms.SplitContainer scQrsMain;
        private System.Windows.Forms.Button btnEnterUnscanned;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.SplitContainer scQrsData;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnQrsSaveData;
        private System.Windows.Forms.CheckBox cbQrsAbsent;
        private System.Windows.Forms.TextBox txtQrsIndexNumber;
        private System.Windows.Forms.TextBox txtQrsCentreNumber;
        private System.Windows.Forms.ComboBox cbQrsSex;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtQrsExamYear;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtQrsData;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.SplitContainer scQrsLeft;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Label lblCurrentQuestion;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button BtnQrsClear;
        private System.Windows.Forms.TextBox txtQrsSubjCode;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtQrsDataConfirm;
        private System.Windows.Forms.RadioButton rbQrsStartFromIndex;
        private System.Windows.Forms.RadioButton rbQrsStartFromCent;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.GroupBox gbQrsKeypad;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.Button btnQrsMulti;
        private System.Windows.Forms.Button btnQrsSpace;
        private System.Windows.Forms.Button btnQrsD;
        private System.Windows.Forms.Button btnQrsC;
        private System.Windows.Forms.Button btnQrsB;
        private System.Windows.Forms.Button btnQrsA;
        private System.Windows.Forms.Button btnQrsShowKeyPad;
        private System.Windows.Forms.Label lblCurrentCaretPosition;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button btnSearchQrsCandidate;
        private System.Windows.Forms.GroupBox gbQrsCheckCandidate;
        private System.Windows.Forms.TextBox txtQrsCheckExamYear;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button btnSearchCheckCandidate;
        private System.Windows.Forms.ListView lvQrsCheckCandidate;
        private System.Windows.Forms.TextBox txtQrsCheckIndexNo;
        private System.Windows.Forms.TextBox txtQrsCheckCentNo;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.Button btnQrsCheckClear;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.CheckBox cbQrsCheckShowUnscored;
        private System.Windows.Forms.CheckBox cbQrsCheckShowManuallyKeyed;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.Button btnQrsCheckShowAbsents;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.DateTimePicker dtpViewSpecificDate;
        private System.Windows.Forms.RadioButton rbViewSpecificDate;
        private System.Windows.Forms.RadioButton rbViewAll;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.RadioButton rbViewIncompleteCentres;
        private System.Windows.Forms.ComboBox cmbViewSpecificUser;
        private System.Windows.Forms.RadioButton rbViewSpecificUser;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.Button btnSortAscDesc;
        private System.Windows.Forms.RichTextBox rtbQrsDisplay;
    }
}