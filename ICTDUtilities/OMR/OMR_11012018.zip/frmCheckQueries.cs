﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WaecLibrary;
using System.Data.OleDb;

namespace CsdUtilities.OMR
{
    public partial class frmCheckQueries : Form
    {
        dbConnection4 db = new dbConnection4();
        DataSet ds;
        DataTable dt;

        string centNo, csdSubjCode;

        public frmCheckQueries(string centreNo, string subjCode, DataTable dt)
        {
            InitializeComponent();

            lblCentreNumber.Text = centreNo;
            lblSubject.Text = subjCode;

            centNo = centreNo;
            csdSubjCode = subjCode;

            this.dt = dt;
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void frmCheckQueries_Load(object sender, EventArgs e)
        {
            // load list of missing candidates for subject from the dt
            lbMissingCandidates.Items.Clear();

            // columns: ExamYear, CentNo, IndexNo, CsdSubjCode
            foreach (DataRow dr in dt.Rows)
            {
                Console.WriteLine(dr["CsdSubjCode"].ToString());
                if (dr["CsdSubjCode"].ToString() == csdSubjCode)
                {
                    //found a match save it
                    lbMissingCandidates.Items.Add("" + dr["CentNo"] + " " + dr["IndexNo"]);
                }
            }
        }


        private bool UpdateDs(string tableName, string sqlStatement)
        {
            try
            {
                if (ds == null)
                    ds = new DataSet();

                // try to remove table first
                try
                {
                    ds.Tables.RemoveAt(ds.Tables.IndexOf(tableName));
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error removing table: " + tableName + ": " + ex.Message);
                }

                OleDbDataAdapter dsAdapter = new OleDbDataAdapter(new OleDbCommand(sqlStatement, new OleDbConnection(db.connectionString)));
                //dsAdapter.SelectCommand.Connection = new OleDbConnection(db.connectionString);
                dsAdapter.SelectCommand.CommandText = sqlStatement;
                dsAdapter.Fill(ds, tableName);
                dsAdapter.Dispose();
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error Updating ds - table: " + tableName + " sql: " + sqlStatement + " : " + ex.Message);
            }
            return false;
        }
    }
}


//SELECT PrePrintObjDetailsWassce.ExamYear, PrePrintObjDetailsWassce.CentNo, PrePrintObjDetailsWassce.IndexNo, PrePrintObjDetailsWassce.CsdSubjCode
//FROM PrePrintObjDetailsWassce LEFT JOIN obj_8_2013 ON (PrePrintObjDetailsWassce.ExamYear = obj_8_2013.ExamYear) AND (PrePrintObjDetailsWassce.CentNo = obj_8_2013.CentNo) AND (PrePrintObjDetailsWassce.IndexNo = obj_8_2013.IndexNo) AND (PrePrintObjDetailsWassce.CsdSubjCode = obj_8_2013.CsdSubjCode)
//WHERE ((obj_8_2013.CsdSubjCode IS NULL) AND (PrePrintObjDetailsWassce.CsdSubjCode = "302343"));